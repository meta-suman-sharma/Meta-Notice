package com.noticeboard.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.noticeboard.model.Comment;
import com.noticeboard.model.Notice;

/**
 * 
 * @author
 * Description: Interface class containing method definition 
 * 				for providing services to comment module
 *
 */
public interface CommentService {

	/**
	 * Method add comments 
	 * @param comment
	 * @return boolean
	 */
	public boolean addComment(Comment comment );

	/**
	 * Method providing list of comments
	 * @param id
	 * @return List of comments
	 */
	public List<Comment> listComments(int id);

	/**
	 * Method used for deleting a comment 
	 * @param id
	 * @return boolean 
	 */
	public Boolean deleteComment(Integer id);

	/**
	 * Method provide notices by comment id
	 * @param commentId
	 * @return Notice object
	 */
	public Notice getNoticeByCommentId(int commentId);

}
