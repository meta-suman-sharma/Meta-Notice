package com.noticeboard.service;

import java.util.List;

import com.noticeboard.model.Notice;
import com.noticeboard.model.User;

/**
 * 
 * @author
 * Description: Interface class containing method definition 
 * 				for providing services to Notice module
 *
 */
public interface NoticeService {

	/**
	 * Method providing add new notice service
	 * @param notice
	 */
	public boolean addNotice(Notice notice);	
	
	/**
	 * Method providing Notices
	 * @param email
	 * @return Notice object
	 */
	public  Notice getNotice(String email);
	
	/**
	 * Method List off notices for super user
	 * @param offset
	 * @param recordsPerPage
	 * @return List of Notices
	 */
	public List<Notice> listNoticeForSuperUser(int i, int recordsPerPage);
	
	/**
	 * Method providing delete notice service
	 * @param noticeId
	 */
	public boolean deleteNotice(int noticeId );
	
	/**
	 * Method providing list of public notices 
	 * @return List of Notices
	 */
	public List<Notice> listNoticePublic();
	
	/**
	 * Method providing list of notices by userId
	 * @param id
	 * @return List of Notices
	 */
	public List<Notice> getNoticeByUserId(int id);
	
	/**
	 * Method providing notice by noticeId
	 * @param id
	 * @return Notice object
	 */
	public Notice getNoticeByNoticeId(int id);
	
	/**
	 * Method updating notice
	 * @param notice
	 */
	public boolean updateNotice(Notice notice);
	
	/**
	 * Method Providing no of notices which fulfill criteria
	 * @return Integer
	 */
	public int getNoOfRecords();
	
	/**
	 * Method providing list of notices by category for superuser
	 * @param offset
	 * @param recordsPerPage
	 * @param string
	 * @return List of Notices
	 */
	public List<Notice> getNoticeByCategoryForAdmin(int i, int recordsPerPage,String string);
	
	/**
	 * Method providing list of notices by category for user 
	 * @param offset
	 * @param recordsPerPage
	 * @param string
	 * @param user
	 * @return List of Notices
	 */
	public List<Notice> getNoticeByCategoryForUser(int i, int recordsPerPage, String string,
			User user);
	
	/**
	 * Method providing list of notices for user
	 * @param offset
	 * @param recordsPerPage
	 * @param user
	 * @return List of Notices
	 */
	public List<Notice> listNoticeForUser(int i, int recordsPerPage,User user);
	
	/**
	 * Method providing list of notices search by user 
	 * @param text
	 * @param user
	 * @return List of Notices
	 */
	public List<Notice> searchNotices(String text,User user);
	
	/**
	 * Method providing list of notices search(Advance Search) by super user
	 * @param category
	 * @param fromDate
	 * @param toDate
	 * @return List of Notices
	 */
	public List<Notice> searchNoticesForAdmin(String category, String fromDate,
			String toDate);
}
