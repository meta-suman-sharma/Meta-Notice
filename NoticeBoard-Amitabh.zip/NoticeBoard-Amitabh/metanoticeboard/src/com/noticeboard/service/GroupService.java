package com.noticeboard.service;

import java.util.List;

import com.noticeboard.model.Group;
import com.noticeboard.model.Notice;
import com.noticeboard.model.User;

/**
 * 
 * @author
 * Description: Interface class containing method definition 
 * 				for providing services to Group module
 *
 */
public interface GroupService {

	/**
	 * method Adding new groups
	 * @param group
	 * @return boolean
	 */
	public boolean addGroup(Group group);

	/**
	 * Method returning list of Groups
	 * @return List of groups
	 */
	public List<Group> listGroups();

	/**
	 * Method Deleting particular group
	 * @param group
	 * @return boolean
	 */
	public Boolean deleteGroup(Group group);

	/**
	 * Method providing list of group notices by user
	 * @param user
	 * @return list of notices
	 */
	public List<Notice> getGroupNoticeByUser(User user);

	/**
	 * Method providing group by group id
	 * @param id
	 * @return Group
	 */
	public Group getGroupById(int id);

	/**
	 * method providing group by group name
	 * @param groupName
	 * @return Group
	 */
	public Group getGroupByName(String groupName);

}
