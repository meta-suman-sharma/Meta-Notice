package com.noticeboard.service;

import java.util.Date;
import java.util.List;
import com.noticeboard.model.User;

/**
 * 
 * @author
 * Description: Interface class containing method definition 
 * 				for providing services to User module
 *
 */
public interface UserService {

	/**
	 * Method add new user
	 * @param user
	 * @return boolean
	 */
	public boolean addUser(User user);

	/**
	 * Method providing user by id
	 * @param id
	 * @return User Object
	 */
	public User getUser(int id);

	/**
	 * Method Providing list of users
	 * @return list of user
	 */
	public List<User> listUsers();

	/**
	 * Method providing service for delete user
	 * @param user
	 */
	public boolean deleteUser(User user);

	/**
	 * Method updating user role
	 * @param user
	 * @return boolean
	 */
	public boolean updateRole(User user);

	/**
	 * Method providing user by email
	 * @param email
	 * @return user object
	 */
	public User getUserByEmail(String email);

	/**
	 * Method providing user list by anniversary date
	 * @param offset
	 * @param noOfRecords
	 * @param date
	 * @return list of user
	 */
	public List<User> getUserByAnniversoryDate(int offset, int noOfRecords);

	/**
	 * Method providing user list by Birth date
	 * @param offset
	 * @param noOfRecords
	 * @param date
	 * @return list of user
	 */
	public List<User> getUserByBirthDayDate(int offset, int noOfRecords);

	/**
	 * Method updating user information
	 * @param user
	 */
	public boolean updateUser(User user);
	
	/**
	 * method providing number of records
	 * @return Integer
	 */
	public int getNoOfRecords();

}
