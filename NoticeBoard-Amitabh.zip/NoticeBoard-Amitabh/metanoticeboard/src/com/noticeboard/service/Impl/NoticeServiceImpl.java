package com.noticeboard.service.Impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.noticeboard.dao.NoticeDao;
import com.noticeboard.model.Notice;
import com.noticeboard.model.User;
import com.noticeboard.service.NoticeService;


/**
 * 
 * @author
 * Description: Class containing method implementation 
 * 				for providing services to Notice module
 *
 */
@Service("noticeService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class NoticeServiceImpl implements NoticeService {

	/**
	 * Object of class "commentDaoImpl"
	 */
	@Autowired
	private NoticeDao noticeDaoImpl;

	/**
	 * Method providing add new notice service
	 * @param notice
	 */
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public boolean addNotice(Notice notice) {
		return noticeDaoImpl.addNotice(notice);
	}

	/**
	 * Method List off notices for super user
	 * @param offset
	 * @param recordsPerPage
	 * @return List of Notices
	 */
	@Transactional
	public List<Notice> listNoticeForSuperUser(int offset, int noOfRecords) {
		return noticeDaoImpl.listNoticeForSuperUser(offset, noOfRecords);
	}

	/**
	 * Method providing Notices
	 * @param email
	 * @return Notice object
	 */
	@Transactional
	public Notice getNotice(String email) {
		return noticeDaoImpl.getNotice(email);
	}

	/**
	 * Method providing delete notice service
	 * @param noticeId
	 */
	@Transactional
	public boolean deleteNotice(int id) {
		return	noticeDaoImpl.deleteNotice(id);
	}

	/**
	 * Method providing list of notices by userId
	 * @param id
	 * @return List of Notices
	 */
	@Transactional
	public List<Notice> getNoticeByUserId(int id) {
		return noticeDaoImpl.getNoticeByUserId(id);
	}

	/**
	 * Method providing notice by noticeId
	 * @param id
	 * @return Notice object
	 */
	@Transactional
	public Notice getNoticeByNoticeId(int id) {
		return noticeDaoImpl.getNoticeByNoticeId(id);
	}

	/**
	 * Method updating notice
	 * @param notice
	 */
	@Transactional
	public boolean updateNotice(Notice notice) {
		return noticeDaoImpl.updateNotice(notice);

	}

	/**
	 * Method providing list of public notices 
	 * @return List of Notices
	 */
	@Transactional
	public List<Notice> listNoticePublic() {
		return noticeDaoImpl.listNoticePublic();
	}

	/**
	 * Method Providing no of notices which fulfill criteria
	 * @return Integer
	 */
	@Transactional
	public int getNoOfRecords() {
		// TODO Auto-generated method stub
		return noticeDaoImpl.getNoOfRecords();
	}

	/**
	 * Method providing list of notices by category for superuser
	 * @param offset
	 * @param recordsPerPage
	 * @param string
	 * @return List of Notices
	 */
	@Transactional
	public List<Notice> getNoticeByCategoryForAdmin(int i, int recordsPerPage,String string) {
		return noticeDaoImpl.getNoticeByCategoryForAdmin(i,recordsPerPage,string);
	}

	/**
	 * Method providing list of notices by category for user 
	 * @param offset
	 * @param recordsPerPage
	 * @param string
	 * @param user
	 * @return List of Notices
	 */
	@Transactional
	public List<Notice> getNoticeByCategoryForUser(int i, int recordsPerPage,
			String string, User user) {
		return noticeDaoImpl.getNoticeByCategoryForUser(i,recordsPerPage,string,user);
	}
	
	/**
	 * Method providing list of notices for user
	 * @param offset
	 * @param recordsPerPage
	 * @param user
	 * @return List of Notices
	 */
	public List<Notice> listNoticeForUser(int offset, int noOfRecords, User user) {

		return noticeDaoImpl.listNoticeForUser(offset, noOfRecords, user);
	}


	/**
	 * Method providing list of notices search by user 
	 * @param text
	 * @param user
	 * @return List of Notices
	 */
	@Transactional
	public List<Notice> searchNotices(String text,User user) {
		return noticeDaoImpl.searchNotices(text,user);
	}
	
	/**
	 * Method providing list of notices search(Advance Search) by super user
	 * @param category
	 * @param fromDate
	 * @param toDate
	 * @return List of Notices
	 */
	@Transactional
	public List<Notice> searchNoticesForAdmin(String category, String fromDate,
			String toDate) {
		return noticeDaoImpl.searchNoticesForAdmin(category,fromDate,toDate);
	}

}
