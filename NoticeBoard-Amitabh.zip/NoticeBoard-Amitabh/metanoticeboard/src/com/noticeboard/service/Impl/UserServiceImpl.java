package com.noticeboard.service.Impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.noticeboard.dao.UserDao;
import com.noticeboard.model.User;
import com.noticeboard.service.UserService;

/**
 * 
 * @author
 * Description: Class containing method implementation 
 * 				for providing services to User module
 *
 */
@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class UserServiceImpl implements UserService {

	/**
	 * Object of class "commentDaoImpl"
	 */
	@Autowired
	private UserDao userDaoImpl;

	/**
	 * Method add new user
	 * @param user
	 * @return boolean
	 */
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public boolean addUser(User user) {
		return userDaoImpl.addUser(user);
	}

	/**
	 * Method Providing list of users
	 * @return list of user
	 */
	@Transactional
	public List<User> listUsers() {
		return userDaoImpl.listUsers();
	}

	/**
	 * Method providing user by id
	 * @param id
	 * @return User Object
	 */
	@Transactional
	public User getUser(int id) {
		return userDaoImpl.getUser(id);
	}

	/**
	 * Method providing service for delete user
	 * @param user
	 */
	@Transactional
	public boolean deleteUser(User user) {
		return userDaoImpl.deleteUser(user);
	}

	/**
	 * Method updating user role
	 * @param user
	 * @return boolean
	 */
	@Transactional
	public boolean updateRole(User user) {
		return userDaoImpl.updateRole(user);

	}

	/**
	 * Method providing user by email
	 * @param email
	 * @return user object
	 */
	@Transactional
	public User getUserByEmail(String email) {
		// TODO Auto-generated method stub
		return userDaoImpl.getUserByEmail(email);
	}

	/**
	 * Method providing user list by anniversary date
	 * @param offset
	 * @param noOfRecords
	 * @param date
	 * @return list of user
	 */
	@Transactional
	public List<User> getUserByAnniversoryDate(int offset, int noOfRecords) {
		return userDaoImpl.getUserByAnniversoryDate(offset, noOfRecords);
	}
	
	/**
	 * Method providing user list by Birth date
	 * @param offset
	 * @param noOfRecords
	 * @param date
	 * @return list of user
	 */
	@Transactional
	public List<User> getUserByBirthDayDate(int offset, int noOfRecords) {
		return userDaoImpl.getUserByBirthDayDate(offset, noOfRecords);
	}
	
	/**
	 * Method updating user information
	 * @param user
	 */
	@Transactional
	public boolean updateUser(User user) {
		return userDaoImpl.updateUser(user);
	}
	
	/**
	 * method providing number of records
	 * @return Integer
	 */
	@Transactional
	public int getNoOfRecords() {
		return userDaoImpl.getNoOfRecords();
	}

}
