package com.noticeboard.service.Impl;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.noticeboard.dao.GroupDao;
import com.noticeboard.model.Group;
import com.noticeboard.model.Notice;
import com.noticeboard.model.User;
import com.noticeboard.service.GroupService;

/**
 * 
 * @author
 * Description: Class containing method implementation 
 * 				for providing services to Group module
 *
 */
@Service("groupService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class GroupServiceImpl implements GroupService {

	/**
	 * Object of class "commentDaoImpl"
	 */
	@Autowired
	private GroupDao groupDaoImpl;

	/**
	 * method Adding new groups
	 * @param group
	 * @return boolean
	 */
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public boolean addGroup(Group group) {
		return groupDaoImpl.addGroup(group);
	}

	/**
	 * Method returning list of Groups
	 * @return List of groups
	 */
	@Transactional
	public List<Group> listGroups() {
		return groupDaoImpl.listGroups();
	}

	/**
	 * Method Deleting particular group
	 * @param group
	 * @return boolean
	 */
	@Transactional
	public Boolean deleteGroup(Group group) {

		return groupDaoImpl.deleteGroup(group);
	}

	/**
	 * Method providing list of group notices by user
	 * @param user
	 * @return list of notices
	 */
	@Transactional
	public List<Notice> getGroupNoticeByUser(User user) {
		return groupDaoImpl.getGroupNoticeByUser(user);
	}

	/**
	 * Method providing group by group id
	 * @param id
	 * @return Group
	 */
	@Transactional
	public Group getGroupById(int id) {
		return groupDaoImpl.getGroupById(id);
	}

	/**
	 * method providing group by group name
	 * @param groupName
	 * @return Group
	 */
	@Transactional
	public Group getGroupByName(String groupName) {
		return groupDaoImpl.getGroupByName(groupName);
	}
}
