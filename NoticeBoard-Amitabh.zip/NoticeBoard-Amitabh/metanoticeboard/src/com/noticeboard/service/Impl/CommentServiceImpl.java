package com.noticeboard.service.Impl;



import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.noticeboard.dao.CommentDao;
import com.noticeboard.dao.GroupDao;
import com.noticeboard.model.Comment;
import com.noticeboard.model.Group;
import com.noticeboard.model.Notice;
import com.noticeboard.service.CommentService;

/**
 * 
 * @author 
 * Description: Class containing method Implementation 
 * 				for providing services to comment module
 *
 */
@Service("commentService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class CommentServiceImpl implements CommentService {

	/**
	 * Object of class "commentDaoImpl"
	 */
	@Autowired
	private CommentDao commentDaoImpl;

	/**
	 * Method add comments 
	 * @param comment
	 * @return boolean
	 */
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public boolean addComment(Comment comment ) {
		return commentDaoImpl.addComment(comment);
	}

	/**
	 * Method providing list of comments
	 * @param id
	 * @return List of comments
	 */
	@Transactional
	public List<Comment> listComments(int id) {
		return commentDaoImpl.listComments(id);
	}

	/**
	 * Method used for deleting a comment 
	 * @param id
	 * @return boolean 
	 */
	@Transactional
	public Boolean deleteComment(Integer id) {
		return commentDaoImpl.deleteComment(id);
	}

	/**
	 * Method provide notices by comment id
	 * @param commentId
	 * @return Notice object
	 */
	@Transactional
	public Notice getNoticeByCommentId(int commentId) {
		return commentDaoImpl.getNoticeByCommentId(commentId);
	}
}
