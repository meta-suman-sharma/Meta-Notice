package test.suite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	test.dao.UserDaoImplTest.class,
	test.service.UserServiceImplTest.class,
	test.service.NoticeServiceImplTest.class,

})
public class JUnitTestSuite {
}
