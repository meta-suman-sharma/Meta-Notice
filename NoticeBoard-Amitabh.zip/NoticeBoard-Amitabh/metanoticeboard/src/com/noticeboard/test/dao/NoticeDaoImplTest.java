package com.noticeboard.test.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.noticeboard.dao.NoticeDao;
import com.noticeboard.model.Comment;
import com.noticeboard.model.Notice;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"file:src/com/noticeboard/test/test-context.xml"})
public class NoticeDaoImplTest {

	@Autowired
	public NoticeDao noticeDao;
			
	private Notice notice = new Notice();
    boolean expected = true;
	Comment comment = new Comment();
	comment.s
	
	/**
	 * 	Set User attributes before test case start executing
	 */
	@Before
	public void setUp() {
		
		notice.setContent("New Notice");
		notice.setHeading("Heading");
	}
	
	/**
	 * to test the method that add Notice
	 */
	@Transactional
	@Test
	public void testAddNotice() {
		assertEquals(true,noticeDao.addNotice(notice));
	}
	
	
	
	/**
	 * to test the method that return list of notice for 
	 * SuperUser
	 */
	
	@Transactional
	@Test
	public void testListNoticeForSuperUser() {
		List<Notice> list = noticeDao.listNoticeForSuperUser(0,5);
		int actualSize = list.size();
	    int expectedSize = 5;
		assertEquals(expectedSize,actualSize );

	}
	
	 /**
	 * to test the method that delete the Notice by Notice id
	 */
	@Transactional
	@Test
	public void testdeleteNotice() {
		
		boolean actual = noticeDao.deleteNotice(18);
		assertEquals(expected, actual );		
	}
	
	
	
	/**
	 * to test the method that return list of
	 * Notices by User id
	 */
	@Transactional
	@Test
	public void testGetNoticeByUserId() {
		
	List<Notice> list =  noticeDao.getNoticeByUserId(3);
	int actual = list.size();
	assertEquals(0, actual);
		
	}
	
	/**
	 * to test the method return Notice by Notice id
	 */
	
	
	@Transactional
	@Test
	public void testGetNoticeByNoticeId() {
		boolean actual = true;
		Notice notice =  noticeDao.getNoticeByNoticeId(39);
		if(notice == null){
			actual = false;
		}
			assertEquals(true, actual);
	}
	
	
	/**
	 * to test the method update the Notice
	 */
	
	@Transactional
	@Test
	public void testUpdateNotice() {
		notice.setNoticeId(10);
		notice.setHeading("heading");
	
		boolean actual = noticeDao.updateNotice(notice);
			assertEquals(true, actual);
	
	}
	

	@After
	public void tearDown() {
		notice = null;
	}

}
