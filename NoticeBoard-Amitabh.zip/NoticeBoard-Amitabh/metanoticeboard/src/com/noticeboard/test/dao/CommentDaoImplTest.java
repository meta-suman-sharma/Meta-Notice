package com.noticeboard.test.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.noticeboard.dao.CommentDao;
import com.noticeboard.dao.NoticeDao;
import com.noticeboard.dao.UserDao;
import com.noticeboard.model.Comment;
import com.noticeboard.model.Notice;
import com.noticeboard.model.User;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"file:src/com/noticeboard/test/test-context.xml"})
public class CommentDaoImplTest {
	
	@Autowired
	public CommentDao commentDao;
	@Autowired
	public NoticeDao noticeDao;
	
	@Autowired
	public UserDao userDao;
	
	private Comment comment = new Comment();
	private Notice notice = new Notice();
	private User user = new User();
	boolean expected = true;

	/**
	 * 	Set User attributes before test case start executing
	 */
	@Before
	public void setUp() {
		notice =noticeDao.getNoticeByNoticeId(3);
		user =userDao.getUser(2);
		comment.setComment("this is comment");
		comment.setNotice(notice);
		comment.setUser(user);
	
	}
	
	/**
	 * to test the method that adds comment object to the table
	 */
	@Transactional
	@Test
	public void testAddComment() {
		assertEquals(expected,  commentDao.addComment(comment));
	}
	
	/**
	 * to test the method that return list of comments
	 * 
	 * 	 */
	

	@Transactional
	@Test
	public void testListComments() {
		
		List<Comment> list =  commentDao.listComments(31);
		int actualSize = list.size();
	    int expectedSize =2;
		assertEquals(expectedSize,actualSize );

	}
	
	 /**
	 * to test the method that delete the comment based on particular comment id
	 */
	@Transactional
	@Test
	public void testDeleteComment() {
		boolean actual =  commentDao.deleteComment(1);
		assertEquals(false, actual );		
	}
	
	
	
	/**
	 * to test the method return notice by comment id
	 */
	@Transactional
	@Test
	public void testGetNoticeByCommentId() {
	boolean actual = true ;
	boolean expected = true;
	Notice list =   commentDao.getNoticeByCommentId(40);
	if(list == null){
		actual = false;
	}
	assertEquals(expected, actual);
	}
	
	

	@After
	public void tearDown() {
		comment = null;
		user=null;
		notice=null;
	}

}