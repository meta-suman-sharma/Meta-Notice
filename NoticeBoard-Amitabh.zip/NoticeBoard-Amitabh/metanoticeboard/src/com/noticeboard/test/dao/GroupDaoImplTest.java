package com.noticeboard.test.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.noticeboard.dao.GroupDao;
import com.noticeboard.model.Group;
import com.noticeboard.model.Notice;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"file:src/com/noticeboard/test/test-context.xml"})
public class GroupDaoImplTest {

	
	
				@Autowired
				public GroupDao groupDao;
						
				private Group group = new Group();
				private Notice notice = new Notice();

				/**
				 * 	Set User attributes before test case start executing
				 */
				@Before
				public void setUp() {
					
					group.setGroupName("testing");
				
				}
				
				/**
				 * to test the method that Add group
				 */
				@Transactional
				@Test
				public void testAddGroup() {
					assertEquals(true, groupDao.addGroup(group));
				}
				
				
				/**
				 * to test the method that return list of groups
				 * 
				 */
			
				@Transactional
				@Test
				public void testListGroups() {
					List<Group> list = groupDao.listGroups();
					int actualSize = list.size();
				    int expectedSize =4;
					assertEquals(expectedSize,actualSize );

				}
				
				 /**
				 * to test the method to delete group
				 */
				@Transactional
				@Test
				public void testDeleteGroup() {
					group.setId(17);
					boolean actual = groupDao.deleteGroup(group);
					assertEquals(true, actual );		
				}
				
				
				/**
				 * to test the method that return group based on group name
				 */
				@Transactional
				@Test
				public void testGetNoticeByName() {
					boolean actual = true;
				Group list =  groupDao.getGroupByName("Public");
				if(list == null){
					actual = false;
				}
				assertEquals(true, actual);
				}
				
				
				/**
				 * to test the method that return Group by Id
				 */
				
				@Transactional
				@Test
				public void testGetGroupById() {
					boolean actual = true;
			
				Group group1 =  groupDao.getGroupById(3);
				if(group1 == null){
				actual = false;
				}
				assertEquals(true, actual);
				}

				

				@After
				public void tearDown() {
					notice = null;
				}
			
		
	}