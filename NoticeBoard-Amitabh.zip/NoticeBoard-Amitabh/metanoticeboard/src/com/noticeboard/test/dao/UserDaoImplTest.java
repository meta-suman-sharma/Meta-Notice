package com.noticeboard.test.dao;

import static org.junit.Assert.assertEquals;

import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.noticeboard.dao.UserDao;
import com.noticeboard.model.User;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/com/noticeboard/test/test-context.xml" })
@Transactional(value = "hibernateTransactionManager")
public class UserDaoImplTest {

	@Autowired
	public UserDao userDao;

	private User user = new User();
	private boolean expected = true;

	/**
	 * Set User attributes before test case start executing
	 */
	@Before
	public void setUp() {
		user.setUserName("Jignesh Mistry");
		user.setEmail("jmistry.mistry@metacube.com");
	}

	/**
	 * to test the method that adds user
	 */
	@Transactional
	@Test
	public void testAddUser() {

		assertEquals(expected, userDao.addUser(user));
	}

	
	
	/**
	 * to test the method that return list of Users
	 */
	
	@Transactional
	@Test
	public void testListUser() {
		List<User> list = userDao.listUsers();
		int beforeListSize = list.size();
		userDao.addUser(user);
		int afterListSize = userDao.listUsers().size();
		assertEquals(beforeListSize+1,afterListSize);

	}

	/**
	 * to test the method that return User by user id
	 */
	@Transactional
	@Test
	public void testGetUserById() {
		User user = userDao.getUser(9);
		boolean actual = true;
		if (user == null) {
			actual = false;
		}
		assertEquals(expected, actual);
	}

	
	/**
	 * to test the method that return the list of users have anniversary today
	 */
	

	@Transactional
	@Test
	public void testgetUserByAnniversoryDate() {
	
		List<User> list = userDao.getUserByAnniversoryDate(0,3);
		int actualSize = list.size();
		int expectedSize = 3;
		assertEquals(expectedSize, actualSize);

	}

	
	
	/**
	 * to test the method that return list of users have birthday Today
	 */
	
	@Transactional
	@Test
	public void testgetUserByBirthDayDate() {
		Date date = new Date();
		List<User> list = userDao.getUserByBirthDayDate(0,3);
		int actualSize = list.size();
		int expectedSize = 3;
		assertEquals(expectedSize, actualSize);
	}

	@After
	public void tearDown() {
		user = null;
	}
}
