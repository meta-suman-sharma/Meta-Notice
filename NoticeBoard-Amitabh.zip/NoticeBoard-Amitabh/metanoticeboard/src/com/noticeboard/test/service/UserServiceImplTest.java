package com.noticeboard.test.service;
import static org.junit.Assert.assertEquals;

import java.util.Date;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.noticeboard.model.*;
import com.noticeboard.service.UserService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"file:src/com/noticeboard/test/test-context.xml"})
public class UserServiceImplTest{
	
	@Autowired
	public UserService userService;
	
	private User user = new User();
	private boolean expected = true;

	/**
	 * 	Set User attributes before test case start executing
	 */
	@Before
	public void setUp() {
		user.setUserName("test");
		user.setEmail("test@metacube.com");
	}
	
	/**
	 * to test the method that adds user object in table Users
	 */
	@Transactional
	@Test
	public void testAddUser() {
		
		assertEquals(false, userService.addUser(user));
	}
	
	
	/**
	 * to test the method that return list of users
	 */
	
	@Transactional
	@Test
	public void testListUser() {
		List<User> list = userService.listUsers();
		int actualSize = list.size();
		int expectedSize =3;
		assertEquals(expectedSize,actualSize );

	}
	
	 /**
	 * to test the method that get user object from User table by user id
	 */
	@Transactional
	@Test
	public void testGetUserById() {
		User user = userService.getUser(1);
		boolean actual = true;
		
		if(user == null){
			 actual = false;
		}
		assertEquals(expected,actual );		
	}
	
	/**
	 * to test the method that update the role of user
	 */
	@Transactional
	@Test
	public void testUpdateRole() {
		boolean actual = userService.updateRole(user);
		assertEquals(expected, actual);
		
	}
	
	
	
	/**
	 * to test the method return the list of users which has anniversary today
	 */
	
	@Transactional
	@Test
	public void testgetUserByAnniversoryDate() {
		Date date = new  Date();
		List<User> list = userService.getUserByAnniversoryDate(0,3);
		int actualSize = list.size();
		int expectedSize =1;
		assertEquals(expectedSize,actualSize );

	}
	
	
	

	/**
	 * to test the method return the list of users which has birthday today
	 */

	@Transactional
	@Test
	public void testgetUserByBirthDayDate() {
		Date date = new  Date();
		List<User> list = userService.getUserByBirthDayDate(0,3);
		int actualSize = list.size();
		int expectedSize =0;
		assertEquals(expectedSize,actualSize );
	}
	

	@After
	public void tearDown() {
		user = null;
	}
}


