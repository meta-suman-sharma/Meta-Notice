package com.noticeboard.test.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.noticeboard.model.Comment;
import com.noticeboard.model.Group;
import com.noticeboard.model.Notice;
import com.noticeboard.model.User;
import com.noticeboard.service.CommentService;
import com.noticeboard.service.GroupService;
import com.noticeboard.service.NoticeService;
import com.noticeboard.service.UserService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"file:src/com/noticeboard/test/test-context.xml"})
public class CommentServiceImplTest {

	@Autowired
	public CommentService commentService;
	@Autowired
	public NoticeService noticeService;
	
	@Autowired
	public UserService userService;
	
	private Comment comment = new Comment();
	private Notice notice = new Notice();
	private User user = new User();

	/**
	 * 	Set User attributes before test case start executing
	 */
	@Before
	public void setUp() {
		notice =noticeService.getNoticeByNoticeId(3);
		user =userService.getUser(2);
		comment.setComment("this is comment");
		comment.setNotice(notice);
		comment.setUser(user);
	
	}
	
	/**
	 * to test the method that adds comment into comment tab
	 */
	
	@Test
	public void testAddComment() {
		assertEquals(true, commentService.addComment(comment));
	}
	
	
/*	@Test
	public void testlistComments() {
		List<Comment> list = commentService.listComments(3);
		int actualSize = list.size();
	    int expectedSize =1;
		assertEquals(expectedSize,actualSize );

	}
	
	 *//**
	 * to test the method that get user object from table by user id
	 *//*
	
	@Test
	public void testdeleteComment() {
		boolean actual = commentService.deleteComment(1);
		assertEquals(false, actual );		
	}
	
	*//**
	 * to test the method that gets list of all users
	 *//*
	@Test
	public void testgetNoticeByCommentId() {
		boolean actual = true;
	Notice list =  commentService.getNoticeByCommentId(1);
	if(list == null){
		actual = false;
	}
	assertEquals(false, actual);
	}
	*/
	

	@After
	public void tearDown() {
		comment = null;
		user=null;
		notice=null;
	}

}
