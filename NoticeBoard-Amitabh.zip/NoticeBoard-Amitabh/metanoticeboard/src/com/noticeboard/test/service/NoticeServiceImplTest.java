package com.noticeboard.test.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.noticeboard.model.Notice;
import com.noticeboard.service.NoticeService;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"file:src/com/noticeboard/test/test-context.xml"})
public class NoticeServiceImplTest {

		
		@Autowired
		public NoticeService noticeService;
				
		private Notice notice = new Notice();

		/**
		 * 	Set User attributes before test case start executing
		 */
		@Before
		public void setUp() {
			
			notice.setContent("New Notice");
			notice.setHeading("Heading");
		}
		
		/**
		 * to test the method that adds Notice object in Notice table
		 */
		@Transactional
		@Test
		public void testAddNotice() {
			assertEquals(true, noticeService.addNotice(notice));
		}
		
		
		/**
		 * to test the method that return list of notices for SuperUser
		 */
		
		
		@Transactional
		@Test
		public void testlistNoticeForSuperUser() {
			List<Notice> list = noticeService.listNoticeForSuperUser(0,5);
			int actualSize = list.size();
		    int expectedSize =1;
			assertEquals(expectedSize,actualSize );

		}
		
		
		 /**
		 * to test the method that delete Notice form the Notice table
		 */
		
		@Transactional
		@Test
		public void testdeleteNotice() {
			
			boolean actual = noticeService.deleteNotice(1);
			assertEquals(false, actual );		
		}
		
		
		/**
		 * to test the method that return Notice by providing user id
		 */
		@Transactional
		@Test
		public void testGetNoticeByUserId() {
			
			
		List<Notice> list =  noticeService.getNoticeByUserId(3);
		int actual = list.size();
			assertEquals(0, actual);
			
		}
		
		
		/**
		 * to test the method that return Notice by providing notice id
		 * 
		 * 		 
		 * 
		 * */
		
		@Transactional
		@Test
		public void testgetNoticeByNoticeId() {
			boolean actual = true;
			Notice notice =  noticeService.getNoticeByNoticeId(3);
			if(notice == null){
				actual = false;
			}
				assertEquals(true, actual);
		}
		
		

		/**
		 * to test the method that return Notice by providing Category
		 * 
		 * 
		 * */
		
	/*	@Transactional
		@Test
		public void testGetNoticeByCategory() {
			List<Notice> list =  noticeService.getNoticeByCategory("Event");
			int actual = list.size();
			assertEquals(1, actual);
		}
		*/
		

		/**
		 * to test the method that update the notice
		 * 
		 * 
		 * */
		@Transactional
		@Test
		public void testUpdateNotice() {
			notice.setNoticeId(11);
			notice.setCategory("a");
			notice.setHeading("as u know");
			boolean actual = noticeService.updateNotice(notice);
			assertEquals(true, actual);
		
		}
		

		@After
		public void tearDown() {
			notice = null;
		}
	
}
