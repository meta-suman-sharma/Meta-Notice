package com.noticeboard.test.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.noticeboard.model.Group;
import com.noticeboard.model.Notice;
import com.noticeboard.service.GroupService;
import com.noticeboard.service.NoticeService;



@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"file:src/com/noticeboard/test/test-context.xml"})
public class GroupServiceImplTest {

				
			@Autowired
			public GroupService groupService;
					
			private Group group = new Group();
			private Notice notice = new Notice();

			/**
			 * 	Set User attributes before test case start executing
			 */
			@Before
			public void setUp() {
				
				group.setGroupName("testing");
			
			}
			
			
			/**
			 * to test the method that add the group
			 */
			
			@Test
			public void testAddGroup() {
				assertEquals(false, groupService.addGroup(group));
			}
			
			
			/**
			 * to test the method which return the list the groups
			 */
		
			@Test
			public void testlistGroups() {
				List<Group> list = groupService.listGroups();
				int actualSize = list.size();
			    int expectedSize =1;
				assertEquals(expectedSize,actualSize );

			}
			
			 /**
			 * to test the method that delete the group
			 */
			
			@Test
			public void testdeleteGroups() {
				group.setId(1);
				boolean actual = groupService.deleteGroup(group);
				assertEquals(false, actual );		
			}
			
			/**
			 * to test the method that return Group based on group name
			 */
			@Test
			public void testGetGroupByName() {
				boolean actual = true;
			Group list =  groupService.getGroupByName("testing");
			if(list == null){
				actual = false;
			}
			assertEquals(true, actual);
			}
			
			
			/**
			 * to test the method that return group object based on group id
			 */
			
			
			@Test
			public void testGetGroupById() {
				boolean actual = true;
		
			Group group1 =  groupService.getGroupById(2);
			if(group1 == null){
			actual = false;
			}
			assertEquals(true, actual);
			}

			

			@After
			public void tearDown() {
				notice = null;
			}
		
	
}
