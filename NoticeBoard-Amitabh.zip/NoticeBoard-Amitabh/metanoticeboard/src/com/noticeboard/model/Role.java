package com.noticeboard.model;

/**
 * 
 * @author 
 * Description: Enum define three types of user 
 *
 */
public enum Role {
 superuser ,poster,user;
}
