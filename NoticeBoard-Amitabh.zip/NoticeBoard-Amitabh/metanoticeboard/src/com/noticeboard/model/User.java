package com.noticeboard.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * 
 * @author 
 * Description: class representing the user information 
 *
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "users")
public class User implements Serializable {

	/**
	 * Unique id of user Auto generated and auto increment
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "user_id")
	private Integer userId;

	/**
	 * Name of user
	 */
	@Column(name = "user_name")
	private String userName;

	/**
	 * department of user
	 */
	@Column(name = "department")
	private String department;

	/**
	 * email id of user
	 */
	@Column(name = "email")
	private String email;

	/**
	 * role of user (Super user/Poster/End user)
	 */
	@Column(name = "role")
	private String role;

	/**
	 * User Date of birth 
	 */
	@Column(name = "date_of_birth")
	private Date dateOfBirth;

	/**
	 * user Anniversary date
	 */
	@Column(name = "anniversory_date")
	private Date anniversorydate;

	/**
	 * date on which user joined th1e company
	 */
	@Column(name = "date_of_joining")
	private Date dateOfJoining;

	/**
	 * Notices for that user
	 */
	@OneToMany(mappedBy = "user", fetch = FetchType.EAGER)
	private Set<Notice> notice = new HashSet<Notice>();

	/**
	 * comments which user write
	 */
	@OneToMany(mappedBy = "user", fetch = FetchType.EAGER)
	private Set<Comment> comment = new HashSet<Comment>();

	/**
	 * Groups to which user belongs
	 */
	@ManyToMany(fetch = FetchType.EAGER, cascade = { CascadeType.PERSIST,
			CascadeType.REMOVE, })
	@JoinTable(name = "group_members", joinColumns = { @JoinColumn(name = "user_id", referencedColumnName = "user_id") }, inverseJoinColumns = { @JoinColumn(name = "group_id", referencedColumnName = "id") })
	private List<Group> group = new ArrayList<Group>();

	/**
	 * Method returns Groups to which user belongs
	 * @return list of Groups
	 */
	public List<Group> getGroup() {
		return group;
	}

	/**
	 * method set Groups to which user belongs
	 * @param group
	 */
	public void setGroup(List<Group> group) {
		this.group = group;
	}

	/**
	 * method return set of comments posted by that user
	 * @return set of comments
	 */
	public Set<Comment> getComment() {
		return comment;
	}

	/**
	 * method set comments posted by that user
	 * @param comment
	 */
	public void setComment(Set<Comment> comment) {
		this.comment = comment;
	}

	/**
	 *Method returns user id
	 * @return Integer value
	 */
	public Integer getUserId() {
		return userId;
	}

	/**
	 * Method Set User id
	 * @param userId
	 */
	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	/**
	 * Method returns user name
	 * @return String value
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * Method set user name
	 * @param userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * Method returns department of user
	 * @return String value
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * Method set department of user 
	 * @param department
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * Method returns email id of user
	 * @return String value
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Method set email id of user
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * method returns the role of user(Super user/Poster/End user)
	 * @return string value
	 */
	public String getRole() {
		return role;
	}

	/**
	 * method set role of user(Super user/Poster/End user)
	 * @param role
	 */
	public void setRole(String role) {
		this.role = role;
	}

	/**
	 * Method returns user date of birth 
	 * @return Date
	 */
	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	/**
	 * Method Set user date of birth
	 * @param dateOfBirth
	 */
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	/**
	 * Method returns Anniversary date of user
	 * @return Date
	 */
	public Date getAnniversorydate() {
		return anniversorydate;
	}

	/**
	 * Method Set Anniversary date of user
	 * @param anniversorydate
	 */
	public void setAnniversorydate(Date anniversorydate) {
		this.anniversorydate = anniversorydate;
	}

	/**
	 * Method returns Joining date of user
	 * @return Date
	 */
	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	/**
	 * Method set joining date of user
	 * @param dateOfJoining
	 */
	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	/**
	 * Method returns notices
	 * @return
	 */
	public Set<Notice> getNotice() {
		return notice;
	}

	/**
	 * Method returns notices
	 * @param notice
	 */
	public void setNotice(Set<Notice> notice) {
		this.notice = notice;
	}

}
