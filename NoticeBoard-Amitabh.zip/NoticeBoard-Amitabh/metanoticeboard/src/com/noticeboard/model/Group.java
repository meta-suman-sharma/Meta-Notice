package com.noticeboard.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * 
 * @author
 *Description: class representing the objects of Group Module
 *It implements the interface Serializable
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "groups")
public class Group implements Serializable {

	/**
	 * Unique id for each group
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Integer id;

	/**
	 * Unique group name
	 */
	@Column(name = "group_name")
	private String groupName;

	/**
	 * one to many mapping between Group and notice
	 */
	@OneToMany(mappedBy = "group", fetch = FetchType.EAGER)
	private Set<Notice> notice = new HashSet<Notice>();

	/**
	 * many to many mapping between Group and User
	 */
	@ManyToMany(fetch = FetchType.EAGER, cascade = { CascadeType.ALL,
			CascadeType.REMOVE })
	@JoinTable(name = "group_members", joinColumns = { @JoinColumn(name = "group_id", referencedColumnName = "id") }, inverseJoinColumns = { @JoinColumn(name = "user_id", referencedColumnName = "user_id") })
	private List<User> user = new ArrayList<User>();

	/**
	 * return list of group members
	 * @return list of user
	 */
	public List<User> getUser() {
		return user;
	}

	/**
	 * set list of users who are member of group
	 * @param user
	 */
	public void setUser(List<User> user) {
		this.user = user;
	}

	/**
	 * return id of comment
	 * @return Integer value
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * Set value of Group id
	 * @param id
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * return Group name
	 * @return String value
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * Set value of Group name
	 * @param groupName
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * return unique set of notices in that group
	 * @return set of notice
	 */
	public Set<Notice> getNotice() {
		return notice;
	}

	/**
	 * Set notices in that particular group
	 * @param notice
	 */
	public void setNotice(Set<Notice> notice) {
		this.notice = notice;
	}

}
