package com.noticeboard.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;

/**
 * 
 * @author
 *Description: class representing the objects of Notice Module
 *It implements the interface Serializable
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "notices")
public class Notice implements Serializable {
	/**
	 * Unique id of notice Auto generated and auto increment
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "notice_id")
	private Integer noticeId;

	/**
	 * Heading of notice
	 */
	@Column(name = "heading")
	private String heading;

	/**
	 * Category of notice i.e announcement,event,client praise
	 */
	@Column(name = "category")
	private String category;

	/**
	 * content of notice
	 */
	@Column(name = "content", columnDefinition = "LONGTEXT")
	private String content;

	/**
	 *Name of user who created the notice
	 */
	@Column(name = "created_by")
	private String createdBy;

	/**
	 * notice creation time
	 */
	@Column(name = "created_time")
	private Date createdTime = new Date();

	/**
	 * User who who update the notice
	 */
	@Column(name = "updated_by")
	private String updatedBy;

	/**
	 * Time at which notice updated
	 */
	@Column(name = "updated_time")
	private Date updatedTime = new Date();;

	/**
	 * return comments corresponding to each notice
	 * @return set of comments
	 */
	public Set<Comment> getComment() {
		return comment;
	}

	/**
	 * Set comments corresponding to each notice
	 * @param comment
	 */
	public void setComment(Set<Comment> comment) {
		this.comment = comment;
	}

	/**
	 * User who receiving Notice
	 */
	@JsonIgnore
	@ManyToOne(cascade = { CascadeType.ALL, CascadeType.REMOVE })
	@JoinColumn(name = "user_id")
	private User user;

	/**
	 * Group in which notice display
	 */
	@JsonIgnore
	@ManyToOne(cascade = { CascadeType.ALL, CascadeType.REMOVE })
	@JoinColumn(name = "group_id", referencedColumnName = "id")
	private Group group;

	/**
	 * Notice Expiry date from Dashboard
	 */
	@Column(name = "date_of_expiry")
	private Date dateOfExpiry;

	
	@JsonIgnore
	@OneToMany(mappedBy = "notice")
	private Set<Attachment> attachment = new HashSet<Attachment>();

	/**
	 * Comments corresponding to each notice
	 */
	@JsonIgnore
	@OneToMany(mappedBy = "notice")
	private Set<Comment> comment = new HashSet<Comment>();

	/**
	 * return User who post notice 
	 * @return User Object
	 */
	public User getUser() {
		return user;
	}

	/**
	 * Set User who post notice
	 * @param user
	 */
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * return Group in which notice displayed
	 * @return Group object
	 */
	public Group getGroup() {
		return group;
	}

	/**
	 * Set Group in which notice displayed
	 * @param group
	 */
	public void setGroup(Group group) {
		this.group = group;
	}

	public Set<Attachment> getAttachment() {
		return attachment;
	}

	public void setAttachment(Set<Attachment> attachment) {
		this.attachment = attachment;
	}

	/**
	 * Method returns notice id
	 * @return Integer value
	 */
	public Integer getNoticeId() {
		return noticeId;
	}

	/**
	 * Method set notice id
	 * @param noticeId
	 */
	public void setNoticeId(Integer noticeId) {
		this.noticeId = noticeId;
	}

	/**
	 * Method returns the heading of notice
	 * @return String value
	 */
	public String getHeading() {
		return heading;
	}

	/**
	 * Method set heading of notice
	 * @param heading
	 */
	public void setHeading(String heading) {
		this.heading = heading;
	}

	/**
	 * method returns the category of notice
	 * @return String value
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * Method set category of notice
	 * @param category
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * Method returns the content of notice
	 * @return string value
	 */
	public String getContent() {
		return content;
	}

	/**
	 * Method set content of notice
	 * @param content
	 */
	public void setContent(String content) {
		this.content = content;
	}

	/**
	 * Method returns the user name who created notice 
	 * @return String value
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Method set user name who created notice
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Method returns creation date of notice
	 * @return date
	 */
	public Date getCreatedTime() {
		return createdTime;
	}

	/**
	 * Method set creation date of notice
	 * @param createdTime
	 */
	public void setCreatedTime(Date createdTime) {
		if (createdTime != null) {
			this.createdTime = createdTime;
		} else {
			this.createdTime = new Date();
		}
	}

	/**
	 * method set default value in case if the value is not set yet.
	 */
	@PrePersist
	public void prePersist() {
		if (createdBy != null) // We set default value in case if the value is
								// not set yet.
			updatedBy = this.createdBy;
	}

	/**
	 * Method returns the user name who update notice
	 * @return String
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * Method set the user name who update notice
	 * @param updatedBy
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;

	}

	/**
	 * Method return time of notice updated
	 * @return Date
	 */
	public Date getUpdatedTime() {
		return updatedTime;
	}

	/**
	 * Method  set time when notice updated
	 * @param updatedTime
	 */
	public void setUpdatedTime(Date updatedTime) {
		if (createdTime != null) {
			this.updatedTime = new Date();
		} else {
			this.updatedTime = updatedTime;
		}
	}

	/**
	 * method return expiry date of notice from notice board
	 * @return date
	 */
	public Date getDateOfExpiry() {
		return dateOfExpiry;
	}

	/**
	 * method set expiry date of notice from notice board
	 * @param dateOfExpiry
	 */
	public void setDateOfExpiry(Date dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}

}
