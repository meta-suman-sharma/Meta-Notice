package com.noticeboard.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * 
 * @author
 *Description: class representing the objects of comment Module
 *It implements the interface Serializable
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "comments")
public class Comment implements Serializable {

	/**
	 * unique id for each comment
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "comment_id")
	private Integer commentId;

	/**
	 * content of comment
	 */
	@Column(name = "comment")
	private String comment;

	/**
	 * id of notice for which comment written
	 */
	@ManyToOne(cascade = { CascadeType.ALL, CascadeType.REMOVE })
	@JoinColumn(name = "notice_id")
	private Notice notice;

	/**
	 * id of user who writes the comment
	 */
	@ManyToOne(cascade = { CascadeType.ALL, CascadeType.REMOVE })
	@JoinColumn(name = "user_id")
	private User user;

	/**
	 * return value of commentId
	 * 
	 * @return Integer value
	 */
	public Integer getCommentId() {
		return commentId;
	}

	/**
	 * set value of commentId
	 * 
	 * @param commentId
	 */
	public void setCommentId(Integer commentId) {
		this.commentId = commentId;
	}

	/**
	 * return value of comment
	 * 
	 * @return String value
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * set value of comment
	 * 
	 * @param comment
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * return corresponding notice object
	 * 
	 * @return notice object
	 */
	public Notice getNotice() {
		return notice;
	}

	/**
	 * set corresponding notice object
	 * 
	 * @param notice
	 */
	public void setNotice(Notice notice) {
		this.notice = notice;
	}

	/**
	 * return corresponding user object who writes the comment
	 * 
	 * @return user object
	 */
	public User getUser() {
		return user;
	}

	/**
	 * set corresponding user object who writes the comment
	 * 
	 * @param user object
	 */
	public void setUser(User user) {
		this.user = user;
	}

}