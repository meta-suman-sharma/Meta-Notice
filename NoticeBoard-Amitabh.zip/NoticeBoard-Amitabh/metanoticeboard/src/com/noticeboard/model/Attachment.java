package com.noticeboard.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.mysql.jdbc.Blob;

@SuppressWarnings("serial")
@Entity
@Table(name = "attachments")
public class Attachment implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "attachment_id")
	private Integer attachmentId;

	@Column(name = "attachment")
	private java.sql.Blob attachment;

	@OneToOne(cascade = { CascadeType.ALL, CascadeType.REMOVE })
	@JoinColumn(name = "notice_id")
	private Notice notice;

	public Integer getAttachmentId() {
		return attachmentId;
	}

	public void setAttachmentId(Integer attachmentId) {
		this.attachmentId = attachmentId;
	}

	public java.sql.Blob getAttachment() {
		return attachment;
	}

	public void setAttachment(java.sql.Blob blob) {
		this.attachment = blob;
	}

	public Notice getNotice() {
		return notice;
	}

	public void setNotice(Notice notice) {
		this.notice = notice;
	}
}
