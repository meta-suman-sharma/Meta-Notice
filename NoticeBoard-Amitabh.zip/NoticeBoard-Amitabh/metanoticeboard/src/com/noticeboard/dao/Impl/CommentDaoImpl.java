package com.noticeboard.dao.Impl;



import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.noticeboard.dao.CommentDao;
import com.noticeboard.model.Comment;
import com.noticeboard.model.Notice;


/**
 * 
 * @author 
 * Description: class containing implementation of methods 
 * for performing tasks of comment module,
 * It implements the interface "CommentDao"
 * 
 */
@Repository("commentDao")
public class CommentDaoImpl implements CommentDao {

	/**
	 * creating Object of "SessionFactory"
	 */
	@Autowired
	private SessionFactory sessionFactory;
	private static Logger logger = Logger.getLogger(CommentDaoImpl.class);
	private static final String MSG = "Exception in CommentDaoImpl";

	/**
	 * Method for adding a new comment
	 * @param comment comment to be added
	 * @return boolean value whether comment is added or not
	 */
	public boolean addComment(Comment comment) {

		boolean status = false;

		try {
			sessionFactory.getCurrentSession().merge(comment);
			status = true;
		} catch (HibernateException hibernateExpection) {

			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateExpection);

		} catch (Exception exception) {
			logger.error(MSG, exception);
		}

		return status;
	}

	
	/**
	 * Method for listing comments for a notice
	 * @param id notice id
	 * @return list of comments
	 */
	@SuppressWarnings("unchecked")
	public List<Comment> listComments(int id) {

		List<Comment> listOfComments = null;

		try {
			String hql = "from Comment where notice_id=" + id;
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			listOfComments = query.list();
			return listOfComments;
		} catch (HibernateException hibernateException) {

			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);

		} catch (Exception exception) {
			logger.error(MSG, exception);
		}

		return listOfComments;
	}

	
	
	/**
	 * Method to delete a comment
	 * @param id id of comment to be deleted
	 * @return boolean value whether comment is deleted or not
	 */
	public Boolean deleteComment(Integer id) {

		boolean status = false;

		try {
			if (sessionFactory
					.getCurrentSession()
					.createQuery("DELETE FROM Comment WHERE comment_id = " + id)
					.executeUpdate() == 0) {
				status = false;
			} else {
				sessionFactory
						.getCurrentSession()
						.createQuery(
								"DELETE FROM Comment WHERE comment_id = " + id)
						.executeUpdate();
				status = true;
			}
		} catch (HibernateException hibernateException) {
			status = false;
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);

		} catch (Exception exception) {
			logger.error(MSG, exception);
		}
		return status;

	}

	
	
	/**
	 * Method to get notice by comment id
	 * @param commentId id of comment
	 * @return notice associated with the comment
	 */
	public Notice getNoticeByCommentId(int commentId) {
		Notice notice = null;
		try {
			Comment comment = (Comment) sessionFactory
					.getCurrentSession()
					.createQuery(
							"from Comment WHERE commentId = '" + commentId
									+ "'").list().get(0);
			notice = comment.getNotice();
		} catch (HibernateException hibernateException) {

			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);

		} catch (Exception exception) {
			logger.error(MSG, exception);
		}
		return notice;

	}
}
