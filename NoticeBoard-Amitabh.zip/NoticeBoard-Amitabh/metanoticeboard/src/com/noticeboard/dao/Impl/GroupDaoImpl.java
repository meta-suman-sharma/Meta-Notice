package com.noticeboard.dao.Impl;


import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.noticeboard.dao.GroupDao;
import com.noticeboard.model.Group;
import com.noticeboard.model.Notice;
import com.noticeboard.model.User;
import com.noticeboard.service.GroupService;

/**
 * 
 * @author 
 * Description: Class containing implementation of methods 
 * for performing tasks of Group module,
 * It implements the interface "GroupDao"
 * 
 */
@Repository("groupDao")
public class GroupDaoImpl implements GroupDao {

	@Autowired
	private SessionFactory sessionFactory;
	@Autowired
	private GroupService groupService;
	private static Logger logger = Logger.getLogger(GroupDaoImpl.class);
	private static final String MSG = "Exception in GroupDaoImpl";

	/**
	 * Method for adding a new group
	 * @param group: group to be added
	 * @return boolean value whether group is successfully
	 * 			added or not
	 * 
	 */
	public boolean addGroup(Group group) {

		boolean status = false;
		try {

			if (sessionFactory
					.getCurrentSession()
					.createQuery(
							"from Group WHERE group_name = '"
									+ group.getGroupName() + "'").list().size() == 0) {

				sessionFactory.getCurrentSession().saveOrUpdate(group);
				status = true;
			} else {
				status = false;
			}
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}

		return status;
	}

	/**
	 * Method to list all the available groups except "Public"
	 * @return list of groups
	 */
	@SuppressWarnings("unchecked")
	public List<Group> listGroups() {

		List<Group> listOfGroup = null;
		try {
			String hql = "from Group WHERE id !=1";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			listOfGroup = query.list();
			return listOfGroup;
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return listOfGroup;
	}

	/**
	 * Method to delete a group
	 * @param group: group to be deleted
	 * @return boolean value whether group is deleted or not
	 */
	public Boolean deleteGroup(Group group) {

		boolean status = false;
		try {
			sessionFactory.getCurrentSession().delete(group);
			status = true;
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}

		return status;

	}

	/**
	 * Method to get all the notices for the groups to
	 * which a user belongs
	 * @param user: user for whom notices are to be find
	 * @return list of notices
	 */
	@SuppressWarnings("unchecked")
	public List<Notice> getGroupNoticeByUser(User user) {

		List<Notice> listNotice = new ArrayList<Notice>();
		List<Group> listGroups = new ArrayList<Group>();
		try {

			listGroups = sessionFactory
					.getCurrentSession()
					.createQuery(
							"from group_members WHERE user_id = "
									+ user.getUserId()).list();
			for (Group group : listGroups) {
				listNotice
						.addAll(sessionFactory
								.getCurrentSession()
								.createQuery(
										"from Notice WHERE group_id = "
												+ group.getId()
												+ "  and Date(dateOfExpiry)>=current_date()")
								.list());
			}
			return listNotice;
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}

		return listNotice;
	}

	/**
	 * Method to get a group by its id
	 * @param id: id of the group
	 * @return group corresponding to the given id
	 */
	public Group getGroupById(int id) {
		Group group = null;
		try {

			group = (Group) sessionFactory.getCurrentSession()
					.createQuery("from Group WHERE id = " + id).list().get(0);
			return group;
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return group;
	}

	/**
	 * Method to get group by its name
	 * @param groupName: name of the group
	 * @return group corresponding to the given name
	 */
	@Override
	public Group getGroupByName(String groupName) {
		Group group = null;
		try {
			group = (Group) sessionFactory
					.getCurrentSession()
					.createQuery(
							"from Group WHERE group_name = '" + groupName + "'")
					.list().get(0);
			return group;
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return group;

	}

}
