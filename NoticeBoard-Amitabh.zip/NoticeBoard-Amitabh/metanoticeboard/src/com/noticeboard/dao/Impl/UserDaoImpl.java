package com.noticeboard.dao.Impl;



import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.noticeboard.dao.UserDao;
import com.noticeboard.model.User;

/**
 * 
 * @author 
 * Description: Class containing implementation of methods 
 * for performing tasks of User module,
 * It implements the interface "UserDao"
 * 
 */
@Repository
public class UserDaoImpl implements UserDao {

	private int noOfRecords;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Autowired
	private SessionFactory sessionFactory;
	private static Logger logger = Logger.getLogger(UserDaoImpl.class);
	private static final String MSG = "Exception in UserDaoImpl";

	/**
	 * Method to add a new user
	 * @param user: user to be added
	 * @return boolean value whether a new user is added successfully
	 * 			or not
	 */
	public boolean addUser(User user) {

		boolean status = false;

		if (user == null)
			return false;

		try {
			if (sessionFactory
					.getCurrentSession()
					.createQuery(
							"from User WHERE email = '" + user.getEmail() + "'")
					.list().size() == 0) {

				sessionFactory.getCurrentSession().saveOrUpdate(user);
				status = true;

			}
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return status;
	}

	/**
	 * Method to list all the users
	 * @return list of users
	 */
	@SuppressWarnings("unchecked")
	public List<User> listUsers() {

		List<User> list = null;
		try {
			Criteria cr = sessionFactory.getCurrentSession().createCriteria(
					User.class);
			cr.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			list = cr.list();
			if (list.size() == 0) {
				return null;
			}
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return list;
	}

	/**
	 * Method to a user by its id
	 * @param id: user id to get the user
	 * @return user corresponding to the given id
	 */
	public User getUser(int id) {

		User user = null;

		try {

			user = (User) sessionFactory.getCurrentSession()
					.createQuery("from User WHERE userId = '" + id + "'")
					.list().get(0);

		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return user;

	}

	/**
	 * Method to delete a user
	 * @param user: user to be deleted
	 */
	public boolean deleteUser(User user) {

		boolean status = false;

		try {
			sessionFactory
					.getCurrentSession()
					.createQuery(
							"DELETE FROM user WHERE user_id = "
									+ user.getUserId()).executeUpdate();
			status = true;
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return status;

	}

	/**
	 * Method to update the role of a user by super user
	 * @param user: user whose role is to be updated
	 * @return boolean value whether role of given user is updated 
	 * 			successfully
	 */
	public boolean updateRole(User user) {

		boolean status = false;

		try {
			if (sessionFactory
					.getCurrentSession()
					.createQuery(
							"from User WHERE email = '" + user.getEmail() + "'")
					.list().size() == 0) {

				status = false;

			} else  {
				
				if (sessionFactory
						.getCurrentSession()
						.createQuery(
								"from User WHERE email = '" + user.getRole() + "'")
						.list().get(0).equals("SuperUser")){
					
					
					return false;
				}

				String hqlUpdate = "update User  set role = :newRole  where email = :Email";

				sessionFactory.getCurrentSession().createQuery(hqlUpdate)
						.setString("newRole", user.getRole())
						.setString("Email", user.getEmail()).executeUpdate();

				status = true;
			}
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return status;

	}

	/**
	 * Method to get user by email
	 * @param email: email corresponding to which user is to be find
	 * @return user for the given email
	 */
	@SuppressWarnings("unchecked")
	public User getUserByEmail(String email) {

		List<User> result = null;
		try {
			Criteria newUsers = sessionFactory.getCurrentSession()
					.createCriteria(User.class);
			newUsers.add(Restrictions.eq("email", email));

			result = newUsers.list();
			if (result.isEmpty()) {
				return null;
			}
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return result.get(0);
	}

	/**
	 * Method to update information of a user
	 * @param user: user whose information is to be updated
	 */
	public boolean updateUser(User user) {

		boolean status = false;

		try {

			sessionFactory.getCurrentSession().update(user);
			status = true;
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return status;

	}

	/**
	 * Method to get list of users having anniversary on the given date
	 * @param offset: initial index from which notices are to be fetched
	 * @param noOfRecords: total number of records to be fetched at a time
	 * @param date: date as the anniversary date
	 * @return list of users
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<User> getUserByAnniversoryDate(int offset, int noOfRecords) {

		List<User> userList = null;

		try {

			String hql = "from User WHERE  month(anniversorydate)=month(current_date()) and day(anniversorydate)=day(current_date())";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			query.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			query.setFirstResult(offset);
			query.setMaxResults(noOfRecords);

			userList = query.list();

			int records = sessionFactory.getCurrentSession().createQuery(hql)
					.list().size();

			if (records != 0) {
				this.noOfRecords = records;
			}
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return userList;
	}

	/**
	 * Method to get list of users having birthday on the given date
	 * @param offset: initial index from which notices are to be fetched
	 * @param noOfRecords: total number of records to be fetched at a time
	 * @param date: date as the birthday date
	 * @return list of users
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<User> getUserByBirthDayDate(int offset, int noOfRecords) {

		List<User> userList = null;

		try {
			String hql = "from User  where month(dateOfBirth)=month(current_date()) and day(dateOfBirth)=day(current_date())";

			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			query.setFirstResult(offset);
			query.setMaxResults(noOfRecords);
			userList = query.list();

			int records = sessionFactory.getCurrentSession().createQuery(hql)
					.list().size();

			if (records != 0) {
				this.noOfRecords = sessionFactory.getCurrentSession()
						.createQuery(hql).list().size();

			}
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return userList;

	}

	/**
	 * Method to get total number of records fulfilling a
	 * particular criteria
	 * @return total number of records
	 */
	@Override
	public int getNoOfRecords() {
		return noOfRecords;
	}

}
