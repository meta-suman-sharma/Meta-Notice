package com.noticeboard.dao.Impl;



import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.noticeboard.dao.NoticeDao;
import com.noticeboard.model.Group;
import com.noticeboard.model.Notice;
import com.noticeboard.model.User;
import com.noticeboard.service.UserService;

/**
 * 
 * @author
 * Description: Class containing implementation of methods 
 * for performing tasks of Notice module,
 * It implements the interface "NoticeDao"
 * 
 */
@Repository("noticeDao")
public class NoticeDaoImpl implements NoticeDao {

	private int noOfRecords;
	@Autowired
	private SessionFactory sessionFactory;
	@Autowired
	private UserService userServiceImpl;
	private static Logger logger = Logger.getLogger(NoticeDaoImpl.class);
	private static final String MSG = "Exception in NoticeDaoImpl";

	/**
	 * Method to add a new notice
	 * @param notice: notice to be added
	 */
	public boolean addNotice(Notice notice) {

		boolean status = false;
		try {
			sessionFactory.getCurrentSession().merge(notice);
			status = true;
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return status;

	}

	/**
	 * Method to list all the notices for the super user
	 * @param offset: initial index from which notices are to be fetched
	 * @param noOfRecords: total number of records to be fetched at a time
	 * @return list of notices
	 */
	@SuppressWarnings("unchecked")
	public List<Notice> listNoticeForSuperUser(int offset, int noOfRecords) {

		List<Notice> noticesList = null;
		try {
			String hql = "FROM Notice WHERE Date(dateOfExpiry)>=current_date() order by createdTime desc";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			query.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

			query.setFirstResult(offset);
			query.setMaxResults(noOfRecords);
			noticesList = query.list();

			int records = sessionFactory.getCurrentSession().createQuery(hql)
					.list().size();

			if (records != 0) {
				this.noOfRecords = records;
			}

		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return noticesList;
	}

	/**
	 * Method to get notice by the email
	 * @param email: email of the corresponding notice posted
	 * @return notice posted by the given email
	 */
	public Notice getNotice(String email) {

		Notice notice = null;
		try {
			notice = (Notice) sessionFactory.getCurrentSession().get(
					Notice.class, email);
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return notice;
	}

	/**
	 * Method to delete a notice by its id
	 * @param id: id of notice to be deleted
	 */
	public boolean deleteNotice(int id) {

		boolean status = false;
		try {
			sessionFactory.getCurrentSession()
					.createQuery("DELETE FROM Notice WHERE notice_id = " + id)
					.executeUpdate();
			status = true;
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return status;
	}

	/**
	 * Method to get all the notices for a particular user by its id
	 * @param id: id of user whose notices are to be find
	 * @return list of notices
	 */
	@SuppressWarnings("unchecked")
	public List<Notice> getNoticeByUserId(int id) {

		List<Notice> notice = null;

		try {
			notice = (List<Notice>) sessionFactory
					.getCurrentSession()
					.createQuery(
							"FROM Notice WHERE user_id = " + id
									+ " and Date(dateOfExpiry)>=current_date()")
					.list();
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return notice;

	}

	/**
	 * Method to get notice by its id
	 * @param id: id of notice to be fetched
	 * @return notice having given id
	 */
	public Notice getNoticeByNoticeId(int id) {
		Notice notice = null;
		try {
			notice = (Notice) sessionFactory.getCurrentSession()
					.createQuery("from Notice WHERE noticeId = " + id).list()
					.get(0);
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return notice;
	}

	/**
	 * method to update the given notice
	 * @param notice: notice to be updated
	 */
	public boolean updateNotice(Notice notice) {
		boolean status = false;
		try {
			sessionFactory.getCurrentSession().merge(notice);
			status = true;
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return status;
	}

	/**
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Notice> listNoticePublic() {

		List<Notice> listOfNotice = null;
		try {
			String hql = "FROM Notice WHERE group_id =1 and Date(dateOfExpiry)>=current_date() order by createdTime desc ";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			query.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

			listOfNotice = query.list();

			int records = listOfNotice.size();

			if (records != 0) {
				this.noOfRecords = records;
			}
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return listOfNotice;

	}

	/**
	 * Method to get total number of records fulfilling a
	 * particular criteria
	 * @return total number of records
	 */
	@Override
	public int getNoOfRecords() {

		return noOfRecords;
	}

	/**
	 * Method to list all the notices of a particular category for super user
	 * @param offset: initial index from which notices are to be fetched
	 * @param recordsPerPage: total number of records to be fetched at a time
	 * @param category: category for which notices are to be fetched
	 * @return list of notices
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Notice> getNoticeByCategoryForAdmin(int offset,
			int recordsPerPage, String category) {

		List<Notice> noticeList = null;

		try {

			String hql = "from Notice WHERE category = '"
					+ category
					+ "' and Date(dateOfExpiry)>=current_date() order by createdTime desc";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			query.setFirstResult(offset);
			query.setMaxResults(recordsPerPage);
			noticeList = query.list();
			int records = sessionFactory.getCurrentSession().createQuery(hql)
					.list().size();

			if (records != 0) {
				this.noOfRecords = records;
			}
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}

		return noticeList;
	}

	/**
	 * Method to list all the notices for a particular user
	 * @param offset: initial index from which notices are to be fetched
	 * @param noOfRecords: total number of records to be fetched at a time
	 * @param user: for which notices are to be fetched
	 * @return list of notices
	 */
	@SuppressWarnings("unchecked")
	public List<Notice> listNoticeForUser(int offset, int noOfRecords, User user) {

		List<Notice> listOfNotice = null;
		try {

			String hql = "FROM Notice WHERE (group_id =1 or user.userId="
					+ user.getUserId() + "  ";
			List<Group> listGroups = new ArrayList<Group>();
			listGroups = user.getGroup();

			for (Group group : listGroups) {
				hql += "or group_id = " + group.getId();
			}
			hql += ") and Date(dateOfExpiry)>=current_date() order by createdTime desc";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			query.setFirstResult(offset);
			query.setMaxResults(noOfRecords);
			query.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			listOfNotice = query.list();

			int records = sessionFactory.getCurrentSession().createQuery(hql)
					.list().size();

			if (records != 0) {
				this.noOfRecords = records;
			}
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return listOfNotice;

	}

	/**
	 * Method to search from all the notices by its heading or content
	 * @param text: text to be matched in the notice heading or content
	 * @param user: for whom searching is performed
	 * @return list of notices
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Notice> searchNotices(String text, User user) {

		List<Group> listGroups = null;

		List<Notice> noticesList = null;

		try {
			String hql = "FROM Notice WHERE (group_id =1 or user.userId="
					+ user.getUserId() + "  ";
			listGroups = new ArrayList<Group>();
			listGroups = user.getGroup();

			for (Group group : listGroups) {
				hql += "or group_id = " + group.getId();
			}

			hql += ") and (heading like '%" + text + "%' or content like '%"
					+ text + "%') order by createdTime desc";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			query.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			noticesList = query.list();
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}

		return noticesList;
	}

	/**
	 * Method to search notices for admin by category or by from date & to date
	 * @param category: notice category to be searched
	 * @param fromDate: starting date from which notices are to be searched
	 * @param toDate: end date up to which notices are to be searched
	 * @return list of notices
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Notice> searchNoticesForAdmin(String category, String fromDate,
			String toDate) {

		List<Notice> noticesList = null;

		try {
			String hql = "";
			Query query;
			if (fromDate == "" && toDate == "" && category == "") {
				System.out.println("nothing selected...");
			} else if ((fromDate == "" || toDate == "") && category != "") {

				hql = "FROM Notice WHERE category='" + category
						+ "' order by createdTime desc";

			} else if (category == "" && fromDate != "" && toDate != "") {

				hql = "FROM Notice WHERE Date(createdTime) BETWEEN Date('"
						+ fromDate + " 00:00:00') AND  Date('" + toDate
						+ " 00:00:00') order by createdTime desc";

			} else if (category != "" && fromDate != "" && toDate != "") {

				hql = "FROM Notice WHERE Date(createdTime) BETWEEN Date('"
						+ fromDate + " 00:00:00') AND  Date('" + toDate
						+ " 00:00:00')";
				hql += "and category='" + category
						+ "' order by createdTime desc";
			} else {
				System.out.println("invalid");
			}

			query = sessionFactory.getCurrentSession().createQuery(hql);
			query.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			noticesList = query.list();
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}
		return noticesList;
	}

	/**
	 * Method to list all the notices of a particular category for the given user
	 * @param offset: initial index from which notices are to be fetched
	 * @param recordsPerPage: total number of records to be fetched at a time
	 * @param category: category for which notices are to be fetched
	 * @param user: for which notices are to be fetched
	 * @return list of notices
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Notice> getNoticeByCategoryForUser(int offset,
			int recordsPerPage, String category, User user) {

		List<Notice> noticeList = null;

		try {
			String hql = "FROM Notice WHERE (group_id =1 or user.userId="
					+ user.getUserId() + "  ";
			List<Group> listGroups = new ArrayList<Group>();
			listGroups = user.getGroup();

			for (Group group : listGroups) {
				hql += "or group_id = " + group.getId();
			}
			hql += ") and category = '" + category + "' ";
			hql += " and Date(dateOfExpiry)>=current_date() order by createdTime desc";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			query.setFirstResult(offset);
			query.setMaxResults(recordsPerPage);
			noticeList = query.list();

			int records = sessionFactory.getCurrentSession().createQuery(hql)
					.list().size();

			if (records != 0) {
				this.noOfRecords = records;

			}
		} catch (HibernateException hibernateException) {
			logger.error(Thread.currentThread().getStackTrace()[2]
					.getLineNumber());
			logger.error(MSG, hibernateException);
		} catch (Exception exception) {

			logger.error(MSG, exception);

		}

		return noticeList;
	}

}
