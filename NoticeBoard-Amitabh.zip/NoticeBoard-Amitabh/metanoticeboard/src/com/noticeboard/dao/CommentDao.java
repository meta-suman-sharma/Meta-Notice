package com.noticeboard.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.noticeboard.model.Comment;
import com.noticeboard.model.Notice;


/**
 * 
 * @author Richa Mittal
 * Description: Interface class containing definition of methods 
 * for performing tasks of comment module
 * 
 */
public interface CommentDao {

	/**
	 * Method for adding a new comment
	 * @param comment: comment to be added
	 * @return boolean value whether comment is successfully 
	 * added or not
	 */
	public boolean addComment(Comment comment);

	
	/**
	 * Method for listing comments for a notice
	 * @param id notice id
	 * @return list of comments
	 */
	public List<Comment> listComments(int id);

	
	/**
	 * Method to delete a comment
	 * @param id id of comment to be deleted
	 * @return boolean value whether comment is deleted or not
	 */
	public Boolean deleteComment(Integer id);

	
	/**
	 * Method to get notice by comment id
	 * @param commentId id of comment
	 * @return notice associated with the comment
	 */
	public Notice getNoticeByCommentId(int commentId);
}
