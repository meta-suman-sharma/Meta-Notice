package com.noticeboard.dao;

import java.util.Date;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.noticeboard.model.Notice;
import com.noticeboard.model.User;

/**
 * 
 * @author Richa Mittal
 * Description: Interface class containing definition of methods 
 * for performing tasks of User module
 * 
 */
public interface UserDao {

	/**
	 * Method to add a new user
	 * @param user: user to be added
	 * @return boolean value whether a new user is added successfully
	 * 			or not
	 */
	public boolean addUser(User user);

	/**
	 * Method to list all the users
	 * @return list of users
	 */
	public List<User> listUsers();

	/**
	 * Method to a user by its id
	 * @param id: user id to get the user
	 * @return user corresponding to the given id
	 */
	public User getUser(int id);

	/**
	 * Method to delete a user
	 * @param user: user to be deleted
	 */
	public boolean deleteUser(User user);

	/**
	 * Method to update the role of a user by super user
	 * @param user: user whose role is to be updated
	 * @return boolean value whether role of given user is updated 
	 * 			successfully
	 */
	public boolean updateRole(User user);

	/**
	 * Method to get user by email
	 * @param email: email corresponding to which user is to be find
	 * @return user for the given email
	 */
	public User getUserByEmail(String email);

	/**
	 * Method to get list of users having anniversary on the given date
	 * @param offset: initial index from which notices are to be fetched
	 * @param noOfRecords: total number of records to be fetched at a time
	 * @param date: date as the anniversary date
	 * @return list of users
	 */
	public List<User> getUserByAnniversoryDate(int offset, int noOfRecords);
	
	/**
	 * Method to get list of users having birthday on the given date
	 * @param offset: initial index from which notices are to be fetched
	 * @param noOfRecords: total number of records to be fetched at a time
	 * @param date: date as the birthday date
	 * @return list of users
	 */
	public List<User> getUserByBirthDayDate(int offset, int noOfRecords);
	
	/**
	 * Method to update information of a user
	 * @param user: user whose information is to be updated
	 */
	public boolean updateUser(User user);
	
	/**
	 * Method to get total number of records fulfilling a
	 * particular criteria
	 * @return total number of records
	 */
	public int getNoOfRecords();
	

}
