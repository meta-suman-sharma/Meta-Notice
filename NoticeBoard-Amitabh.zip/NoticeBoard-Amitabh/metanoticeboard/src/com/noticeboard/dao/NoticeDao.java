package com.noticeboard.dao;

import java.util.List;

import com.noticeboard.model.Notice;
import com.noticeboard.model.User;

/**
 * 
 * @author Richa Mittal
 * Description: Interface class containing definition of methods 
 * for performing tasks of Notice module
 * 
 */
public interface NoticeDao {

	/**
	 * Method to add a new notice
	 * @param notice: notice to be added
	 */
	public boolean addNotice(Notice notice);

	/**
	 * Method to get notice by the email
	 * @param email: email of the corresponding notice posted
	 * @return notice posted by the given email
	 */
	public Notice getNotice(String email);

	/**
	 * Method to list all the notices for the super user
	 * @param offset: initial index from which notices are to be fetched
	 * @param noOfRecords: total number of records to be fetched at a time
	 * @return list of notices
	 */
	public List<Notice> listNoticeForSuperUser(int offset, int noOfRecords);

	/**
	 * Method to delete a notice by its id
	 * @param id: id of notice to be deleted
	 */
	public boolean deleteNotice(int id);

	/**
	 * 
	 * @return
	 */
	public List<Notice> listNoticePublic();

	/**
	 * Method to get all the notices for a particular user by its id
	 * @param id: id of user whose notices are to be find
	 * @return list of notices
	 */
	public List<Notice> getNoticeByUserId(int id);

	/**
	 * Method to get notice by its id
	 * @param id: id of notice to be fetched
	 * @return notice having given id
	 */
	public Notice getNoticeByNoticeId(int id);

	/**
	 * method to update the given notice
	 * @param notice: notice to be updated
	 */
	public boolean updateNotice(Notice notice);

	/**
	 * Method to get total number of records fulfilling a
	 * particular criteria
	 * @return total number of records
	 */
	public int getNoOfRecords();

	/**
	 * Method to list all the notices of a particular category for super user
	 * @param offset: initial index from which notices are to be fetched
	 * @param recordsPerPage: total number of records to be fetched at a time
	 * @param category: category for which notices are to be fetched
	 * @return list of notices
	 */
	public List<Notice> getNoticeByCategoryForAdmin(int i, int recordsPerPage,String string);
	
	/**
	 * Method to list all the notices of a particular category for the given user
	 * @param offset: initial index from which notices are to be fetched
	 * @param recordsPerPage: total number of records to be fetched at a time
	 * @param category: category for which notices are to be fetched
	 * @param user: for which notices are to be fetched
	 * @return list of notices
	 */
	public List<Notice> getNoticeByCategoryForUser(int i, int recordsPerPage,
			String string, User user);

	/**
	 * Method to list all the notices for a particular user
	 * @param offset: initial index from which notices are to be fetched
	 * @param noOfRecords: total number of records to be fetched at a time
	 * @param user: for which notices are to be fetched
	 * @return list of notices
	 */
	public List<Notice> listNoticeForUser(int offset, int noOfRecords, User user);


	/**
	 * Method to search from all the notices by its heading or content
	 * @param text: text to be matched in the notice heading or content
	 * @param user: for whom searching is performed
	 * @return list of notices
	 */
	public List<Notice> searchNotices(String text,User user);
	
	/**
	 * Method to search notices for admin by category or by from date & to date
	 * @param category: notice category to be searched
	 * @param fromDate: starting date from which notices are to be searched
	 * @param toDate: end date up to which notices are to be searched
	 * @return list of notices
	 */
	public List<Notice> searchNoticesForAdmin(String category, String fromDate,
			String toDate);

}
