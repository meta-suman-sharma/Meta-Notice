package com.noticeboard.dao;

import java.util.List;

import com.noticeboard.model.Group;
import com.noticeboard.model.Notice;
import com.noticeboard.model.User;

/**
 * 
 * @author Richa Mittal
 * Description: Interface class containing definition of methods 
 * for performing tasks of Group module
 * 
 */
public interface GroupDao {

	/**
	 * Method for adding a new group
	 * @param group: group to be added
	 * @return boolean value whether group is successfully
	 * 			added or not
	 * 
	 */
	public boolean addGroup(Group group);

	/**
	 * Method to list all the available groups except "Public"
	 * @return list of groups
	 */
	public List<Group> listGroups();

	/**
	 * Method to delete a group
	 * @param group: group to be deleted
	 * @return boolean value whether group is deleted or not
	 */
	public Boolean deleteGroup(Group group);

	/**
	 * Method to get all the notices for the groups to
	 * which a user belongs
	 * @param user: user for whom notices are to be find
	 * @return list of notices
	 */
	public List<Notice> getGroupNoticeByUser(User user);

	/**
	 * Method to get a group by its id
	 * @param id: id of the group
	 * @return group corresponding to the given id
	 */
	public Group getGroupById(int id);

	/**
	 * Method to get group by its name
	 * @param groupName: name of the group
	 * @return group corresponding to the given name
	 */
	public Group getGroupByName(String groupName);

}
