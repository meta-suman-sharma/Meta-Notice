package com.noticeboard.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.noticeboard.model.Comment;
import com.noticeboard.model.Notice;
import com.noticeboard.model.User;
import com.noticeboard.service.CommentService;
import com.noticeboard.service.GroupService;
import com.noticeboard.service.NoticeService;
import com.noticeboard.service.UserService;


/**
 * 
 * @author 
 * Description: This controller defines methods to perform tasks for 
 * 				Comment module
 */
@Controller("/CommentController")
public class CommentController {


	@Autowired
	private UserService userServiceImpl;
	@Autowired
	private NoticeService noticeService;
	@Autowired
	private GroupService groupService;
	@Autowired
	private CommentService commentService;

	/**
	 * method will post a comment to a particular notice
	 * @param id: id of the notice
	 * @param comment: comment to be posted
	 * @param result: result binded from the view
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/postComment", method = RequestMethod.POST)
	public ModelAndView postComment(@RequestParam("id") int id,
			@ModelAttribute("command") Comment comment, BindingResult result,
			HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
		Map<String, Object> model = new HashMap<String, Object>();
        Notice notice = noticeService.getNoticeByNoticeId(id);
		comment.setNotice(notice);
		User user = null;
		user = (User) request.getSession(false).getAttribute("user");
		comment.setUser(user);
		commentService.addComment(comment);
		model.put("notice", noticeService.getNoticeByNoticeId(id));
		model.put("comments", commentService.listComments(id));
		model.put("comment", new Comment());
		return new ModelAndView("NoticeContent", model);
		}
	}

	/**
	 * method will delete a comment from a particular notice
	 * @param commentId: id of the comment
	 * @param notice: notice from which comment is to be deleted
	 * @param result: result binded from the view
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/deleteComment", method = RequestMethod.POST)
	public ModelAndView deleteComment(@RequestParam("commentId") int commentId,
			@ModelAttribute("command") Notice notice, BindingResult result,HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
		Notice noticeObj = commentService.getNoticeByCommentId(commentId);
		commentService.deleteComment(commentId);
		return new ModelAndView("redirect:/noticecontent.html?id="
				+ noticeObj.getNoticeId());
		}
	}
}
