package com.noticeboard.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.noticeboard.model.Comment;
import com.noticeboard.model.Notice;
import com.noticeboard.model.User;
import com.noticeboard.service.CommentService;
import com.noticeboard.service.GroupService;
import com.noticeboard.service.NoticeService;
import com.noticeboard.service.UserService;

/**
 * 
 * @author 
 * Description: This controller defines methods to perform tasks for 
 * 				Notice module
 */
@Controller("/NoticeController")
public class NoticeController {
	
	/**
	 * Object of "UserService"
	 */
	@Autowired
	private UserService userServiceImpl;
	
	/**
	 * Object of "NoticeService"
	 */
	@Autowired
	private NoticeService noticeService;
	
	/**
	 * Object of "GroupService"
	 */
	@Autowired
	private GroupService groupService;
	
	/**
	 * Object of "CommentService"
	 */
	@Autowired
	private CommentService commentService;

	
	/**
	 * Method to list all the available groups on post notice page and
	 * to perform validations on the form values
	 * @param groupName: selected group to post notice
	 * @param content: content to be posted
	 * @param notice: notice to be posted
	 * @param result: result binded from the view
	 * @param request: request parameter
	 * @return new modelAndView 
	 * @throws IOException
	 */
	@RequestMapping(value = "/noticepost", method = RequestMethod.POST)
	public ModelAndView noticePost(@RequestParam("groupName") String groupName,
			@RequestParam("content") String content,
			@ModelAttribute("command") Notice notice, BindingResult result,
			HttpServletRequest request) throws IOException {
		Date date = new Date();
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			Map<String, String> model = new HashMap<String, String>();
			if (groupName == "") {
				model.put("error", "Please enter a valid Group Name....!");
				return new ModelAndView("Post", model);
			} else if (content == "") {
				model.put("error", "Please enter Notice to post....!");
				return new ModelAndView("Post", model);
			} else if (notice.getHeading() == "") {
				model.put("error", "Please enter Heading....!");
				return new ModelAndView("Post", model);
			} else if (notice.getCategory() == "") {
				model.put("error", "Please Select Category....!");
				return new ModelAndView("Post", model);
			} else if (notice.getDateOfExpiry() == null
					|| notice.getDateOfExpiry().before(date)) {
				model.put("error", "Please Select Valid Expiry Date....!");
				return new ModelAndView("Post", model);
			}
			notice.setGroup(groupService.getGroupByName(groupName));
			if (notice.getGroup().getGroupName() == "") {
				model.put("error", "Please Enter Valid Group Name....!");
				return new ModelAndView("Post", model);
			}
			notice.setContent(content);
			User user = (User) request.getSession(false).getAttribute("user");
			notice.setCreatedBy(user.getUserName());
			notice.setUser(user);
			boolean status = noticeService.addNotice(notice);
			if (!status) {
				model.put("error", "Sorry!!!Your Notice could not posted....!");
				return new ModelAndView("Post", model);
			}
			return new ModelAndView("redirect:/UserHome.html?page=1");
		}
	}

	
	/**
	 * Method to delete a notice
	 * @param noticeId: id of notice to be deleted
	 * @param notice: notice to be deleted
	 * @param result: result binded from the view
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/deleteNotice", method = RequestMethod.POST)
	public ModelAndView deleteNotice(@RequestParam("id") int noticeId,
			@ModelAttribute("command") Notice notice, BindingResult result,
			HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			noticeService.deleteNotice(noticeId);
			return new ModelAndView("redirect:/UserHome.html?page=1");
		}
	}

	
	/**
	 * Method to get a notice on Update notice page
	 * @param noticeId: id of notice to be updated
	 * @param notice: notice to be updated
	 * @param result: result binded from the view
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/updateNotice")
	public ModelAndView updateNotice(@RequestParam("id") int noticeId,
			@ModelAttribute("command") Notice notice, BindingResult result,
			HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			Map<String, Object> model = new HashMap<String, Object>();
			Notice notice1 = noticeService.getNoticeByNoticeId(noticeId);
			model.put("notice", notice1);
			model.put("group", notice1.getGroup());
			model.put("groups", groupService.listGroups());
			return new ModelAndView("Post", model);
		}
	}

	
	/**
	 * Method to Update a notice
	 * @param noticeId: id of notice to be updated
	 * @param content: content of notice
	 * @param groupName: name of group
	 * @param notice: notice object
	 * @param result: result binded from the view
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/noticeUpdate", method = RequestMethod.POST)
	public ModelAndView noticeUpdate(@RequestParam("id") int noticeId,
			@RequestParam("content") String content,
			@RequestParam("groupName") String groupName,
			@ModelAttribute("command") Notice notice, BindingResult result,
			HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			Map<String, Object> model = new HashMap<String, Object>();
			Notice notice1 = noticeService.getNoticeByNoticeId(noticeId);
			User user = (User) request.getSession(false).getAttribute("user");
			notice1.setGroup(groupService.getGroupByName(groupName));
			notice1.setContent(content);
			notice1.setHeading(notice.getHeading());
			notice1.setCategory(notice.getCategory());
			notice1.setDateOfExpiry(notice.getDateOfExpiry());
			notice1.setUpdatedBy(user.getUserName());
			notice1.setUpdatedTime(new Date());
			noticeService.updateNotice(notice1);
			return new ModelAndView("redirect:/UserHome.html?page=1", model);
		}
	}

	/**
	 * Method to get complete notice contents of a particular notice
	 * @param id: id of notice
	 * @param notice: notice object
	 * @param result: result binded from the view
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/noticecontent")
	public ModelAndView listNoticeById(@RequestParam("id") int id,
			@ModelAttribute("command") Notice notice, BindingResult result,
			HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			Map<String, Object> model = new HashMap<String, Object>();
			model.put("notice", noticeService.getNoticeByNoticeId(id));
			model.put("comments", commentService.listComments(id));
			model.put("comment", new Comment());
			return new ModelAndView("NoticeContent", model);
		}
	}

	/**
	 * Method to pass notice object and list of all groups on post
	 * notice page
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/post", method = RequestMethod.GET)
	public ModelAndView post(HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			Map<String, Object> model = new HashMap<String, Object>();

			model.put("command", new Notice());

			model.put("groups", groupService.listGroups());
			return new ModelAndView("Post", model);
		}
	}

	/**
	 * Method to get all the notices for public
	 * @return list of notices
	 */
	@RequestMapping(value = "/getAllNotice", method = RequestMethod.GET)
	public @ResponseBody List<Notice> getNoticeInJSON() {

		return noticeService.listNoticePublic();

	}

	/**
	 * Method to search notices for all categories
	 * @param text: text by which notice is to be searched
	 * @param request: request parameter
	 * @return list of notices
	 */
	@RequestMapping(value = "/searchNotices")
	public @ResponseBody List<Notice> searchNotices(
			@RequestParam("CHARS") String text, HttpServletRequest request) {
		System.out.println("hello inside search controller");
		if (text.length() == 0) {
			return null;
		}
		User user = (User) request.getSession().getAttribute("user");
		return noticeService.searchNotices(text, user);
	}

	/**
	 * Method to search notices for Super User by categories and date
	 * @param category: category to be searched
	 * @param fromDate: from date
	 * @param toDate: to date
	 * @param request: request parameter
	 * @return new modelAndView 
	 * @throws ParseException
	 */
	@RequestMapping(value = "/searchNoticesForAdmin", method = RequestMethod.GET)
	public ModelAndView searchNoticesForAdmin(
			@RequestParam("category") String category,
			@RequestParam("fromDate") String fromDate,
			@RequestParam("toDate") String toDate, HttpServletRequest request)
			throws ParseException {
		System.out.println("hello inside searchForAdmin controller");

		if ((category == "") && (fromDate == "") && (toDate == "")) {
			request.setAttribute("error",
					"You must choose atleast one option....");
			return new ModelAndView("SearchResult");
		}
		if (category == "" && (fromDate == "" || toDate == "")) {
			request.setAttribute("error",
					"From Date/To Date should not be Empty....");
			return new ModelAndView("SearchResult");
		}
		if ((category == "") && !(fromDate == "" && toDate == "")) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date dateFrom = dateFormat.parse(fromDate);
			Date dateTo = dateFormat.parse(toDate);

			if (dateFrom.after(dateTo)) {
				request.setAttribute("error",
						"From Date should be Less than To Date....");
				return new ModelAndView("SearchResult");
			} else if (dateTo.before(dateFrom)) {
				request.setAttribute("error",
						"To Date should be Greater than From Date....");
				return new ModelAndView("SearchResult");
			} else if (dateFrom.after(new Date())) {
				request.setAttribute("error",
						"From Date should not be Greater than From Today....");
				return new ModelAndView("SearchResult");
			} else if (dateTo.after(new Date())) {
				request.setAttribute("error",
						"To Date should not be Greater than From Today....");
				return new ModelAndView("SearchResult");
			}
		}
		Map<String, Object> model = new HashMap<String, Object>();
		System.out.println(category + "******" + fromDate + "******" + toDate);
		List<Notice> list = noticeService.searchNoticesForAdmin(category,
				fromDate, toDate);
		model.put("searchedNotices", list);
		model.put("count", list.size());
		return new ModelAndView("SearchResult", model);
	}

}
