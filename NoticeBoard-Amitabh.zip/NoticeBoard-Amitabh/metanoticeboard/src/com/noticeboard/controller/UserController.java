package com.noticeboard.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.noticeboard.model.Notice;
import com.noticeboard.model.Role;
import com.noticeboard.model.User;
import com.noticeboard.service.CommentService;
import com.noticeboard.service.GroupService;
import com.noticeboard.service.NoticeService;
import com.noticeboard.service.UserService;

/**
 * 
 * @author 
 * Description: This controller defines methods to perform tasks for 
 * 				User module
 */
@Controller("/UserController")
public class UserController {
	public UserService getUserServiceImpl() {
		return userServiceImpl;
	}

	public void setUserServiceImpl(UserService userServiceImpl) {
		this.userServiceImpl = userServiceImpl;
	}

	public NoticeService getNoticeService() {
		return noticeService;
	}

	public void setNoticeService(NoticeService noticeService) {
		this.noticeService = noticeService;
	}

	/**
	 * Object of "UserService"
	 */
	@Autowired
	private UserService userServiceImpl;
	
	/**
	 * Object of "NoticeService"
	 */
	@Autowired
	private NoticeService noticeService;
	
	/**
	 * Object of "GroupService"
	 */
	@Autowired
	private GroupService groupService;
	
	/**
	 * Object of "CommentService"
	 */
	@Autowired
	private CommentService commentService;

	/**
	 * Method to add a new user
	 * @param user: user to be added
	 * @param result: result binded from the view
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ModelAndView addUser(@ModelAttribute("command") User user,
			BindingResult result,HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} 
		
		else {
		
		Map<String, String> model = new HashMap<String, String>();
		String error;
		
		String EMAIL_REGEX = "^[\\w-_\\.+]*(@metacube.com)";
		String USER_NAME_REGIX ="([a-zA-Z]{3,30}\\s*)+";
		
		if((user.getUserName() == "")||(user.getUserName().length() < 3)){
			
			error="Please enter a valid user name....!\n";
			return new ModelAndView("CreateUser",model);
			
		}else if(!user.getUserName().matches(USER_NAME_REGIX)){
			
			error="Username can have only alphabates..!\n";
			model.put("error", "Username can have only alphabates..! ");
			return new ModelAndView("CreateUser",model);
			
		}else if(user.getEmail() == ""){
		
			error="Please enter Email....!\n";
			model.put("error", "Please enter Email....!");
			return new ModelAndView("CreateUser",model);
		
		}else if(!user.getEmail().matches(EMAIL_REGEX)){
			
			error="Please enter Valid Email with domain name @metacube.com....!\n";
			model.put("error", "Please enter Valid Email with domain name @metacube.com....!");
			return new ModelAndView("CreateUser",model);
		
		}else if(user.getRole() == ""){
			
			error="Please Select Role of User....!\n";
			model.put("error"," Please Select Role of User....!");
			return new ModelAndView("CreateUser",model);
		}else if(user.getDepartment() == ""){
			
			error="Please Select Department of User....!\n";
			model.put("error", "please Select Department of User....!");
			return new ModelAndView("CreateUser",model);
		}else if(user.getDateOfBirth() == null){
			
			error="Please enter Date Of Birth....!";
			model.put("error", "please enter Date Of Birth....!");
			return new ModelAndView("CreateUser",model);
		}
		else if(user.getDateOfJoining() == null){
			
			error="Please enter Date Of Joining....!\n";
			model.put("error", "please enter Date Of Joining....!");
			return new ModelAndView("CreateUser",model);
		}
			
		
		
		Boolean status = userServiceImpl.addUser(user);
		
		if(status == false){
			model.put("error", "User already Exist or could not Added....!");
			return new ModelAndView("CreateUser",model);
		}
		
		return new ModelAndView("redirect:/UserHome.html?page=1");
		}
	}


	/**
	 * Method to get list of all the users
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public ModelAndView listEmployees(HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
		
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("users", userServiceImpl.listUsers());
		return new ModelAndView("userList", model);
	
		}
		
	}

	
	/**
	 * Method to assign role to user by super user
	 * @param user: to whom role is to be assigned
	 * @param result: result binded from the view
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/role", method = RequestMethod.POST)
	public ModelAndView defineRole(@ModelAttribute("command") User user,
			BindingResult result,HttpServletRequest request) {
		
		
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			
			System.out.println(user.getRole());
			String EMAIL_REGEX = "^[\\w-_\\.+]*(@metacube.com)";
			Map<String, String> model = new HashMap<String, String>();
		if(user.getEmail() == ""||(!user.getEmail().matches(EMAIL_REGEX))){
			model.put("error", "Please enter a valid user Email....!");
			
			return new ModelAndView("DefineRole",model);
		}else if(user.getRole() == null){
			
			model.put("error", "Please select Role....!");
			return new ModelAndView("DefineRole",model);
		}
		Boolean status = false;
		status = userServiceImpl.updateRole(user);
		if(!status){
			
			model.put("error", "User not Exist or could not Updated....!");
			return new ModelAndView("DefineRole",model);
		}
		return new ModelAndView("redirect:/UserHome.html?page=1");
		}
	}

	/**
	 * Method for getting error and displayong on page
	 * @return
	 */
	@RequestMapping(value = "/hderror", method = RequestMethod.GET)
	public ModelAndView errorPage() {
		return new ModelAndView("hderror");
	}

	/**
	 * Method to list all the notices for a user on home page
	 * @param pageNo: page number for which notices are to get
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/UserHome", method = RequestMethod.GET)
	public ModelAndView welcomeUser(@RequestParam("page") int pageNo,
			HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			Map<String, Object> model = new HashMap<String, Object>();
			List<Notice> list = new ArrayList<Notice>();
			User user = (User) request.getSession().getAttribute("user");
			int page = 1;
			int recordsPerPage = 3;
			page = pageNo;
			if (user.getRole().equals("SuperUser")) {
				for (Notice notice : noticeService.listNoticeForSuperUser(
						((page - 1) * recordsPerPage), recordsPerPage)) {
					list.add(notice);

				}
			} else {
				for (Notice notice : noticeService.listNoticeForUser(
						((page - 1) * recordsPerPage), recordsPerPage, user)) {
					list.add(notice);
				}

			}

			int noOfRecords = noticeService.getNoOfRecords();
			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
			model.put("noOfPages", noOfPages);
			model.put("currentPage", page);
			model.put("notices", list);
			model.put("user", user);
			model.put("selectedTab",1);
			model.put("url","UserHome");
			return new ModelAndView("UserHome", model);
		}
	}

	/**
	 * Method to list all the roles on Assign user page
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/define", method = RequestMethod.GET)
	public ModelAndView defineRole(HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {

			Map<String, Object> model = new HashMap<String, Object>();
			List<String> roles = new ArrayList<String>();
			for (Role role : Role.values()) {
				roles.add(role.toString());

			}

			model.put("users", userServiceImpl.listUsers());
			model.put("command", new User());
			return new ModelAndView("DefineRole", model);
		}
	}

	/**
	 * Method to create a new user
	 * @param model: returns user object from view
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView createUser(Model model, HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			model.addAttribute("command", new User());
			return new ModelAndView("CreateUser");
		}
	}

	
	/**
	 * Method to get user information on sign in and display on user profile
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/signUp", method = RequestMethod.GET)
	public ModelAndView editUser(HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {

			Map<String, Object> model = new HashMap<String, Object>();
			User user = (User) request.getSession(false).getAttribute("user");
			User user1 = userServiceImpl.getUser(user.getUserId());
			model.put("command", user1);
			System.out.println("on click on sign up"
					+ user1.getAnniversorydate());
			return new ModelAndView("UserInformation", model);
		}
	}

	/**
	 * 
	 * @param user
	 * @param result
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView deleteUser(@ModelAttribute("command") User user,
			BindingResult result, HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			Map<String, Object> model = new HashMap<String, Object>();
			model.put("command", userServiceImpl.getUser(user.getUserId()));
			model.put("users", userServiceImpl.listUsers());
			return new ModelAndView("adduser", model);
		}
	}

	
	/**
	 * Method to update user information
	 * @param user: whose information is to be updated
	 * @param result: result binded from the view
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/updateUser", method = RequestMethod.POST)
	public ModelAndView updateUser(@ModelAttribute("command") User user,
			BindingResult result, HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {

			User sessionUser = (User) request.getSession().getAttribute("user");
			user.setUserId(sessionUser.getUserId());
			user.setRole(sessionUser.getRole());
			user.setEmail(sessionUser.getEmail());
			user.setUserName(sessionUser.getUserName());
			System.out.println("after updation of form "
					+ user.getAnniversorydate());
			userServiceImpl.updateUser(user);
			return new ModelAndView("redirect:/UserHome.html?page=1");
		}
	}

	/**
	 * Method for signing out a user
	 * @param map
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/SignOut")
	public ModelAndView signOut(Map<String, Object> map,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) {

		if (request.getSession().getAttribute("user") != null) {
			session = request.getSession(false);
			session.removeAttribute("user");

			session.invalidate();

		}
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Pragma", "no-cache"); // HTTP 1.0
		response.setHeader("Cache-Control", "no-store"); // HTTP 1.1
		response.setDateHeader("Expires", 0); // prevents caching at the proxy
												// server

		return new ModelAndView("index");

	}

}
