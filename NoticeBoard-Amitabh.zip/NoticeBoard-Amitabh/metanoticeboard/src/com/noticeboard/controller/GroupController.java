package com.noticeboard.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.noticeboard.model.Group;
import com.noticeboard.model.User;
import com.noticeboard.service.CommentService;
import com.noticeboard.service.GroupService;
import com.noticeboard.service.NoticeService;
import com.noticeboard.service.UserService;

/**
 * 
 * @author 
 * Description: This controller defines methods to perform tasks for 
 * 				Group module
 */
@Controller("/GroupController")
public class GroupController {

	/**
	 * Object of "UserService"
	 */
	@Autowired
	private UserService userServiceImpl;
	
	/**
	 * Object of "NoticeService"
	 */
	@Autowired
	private NoticeService noticeService;
	
	/**
	 * Object of "GroupService"
	 */
	@Autowired
	private GroupService groupService;
	
	/**
	 * Object of "CommentService"
	 */
	@Autowired
	private CommentService commentService;

	/**
	 * Method to create a new group
	 * @param listOfMembers: list of members to be included in the group
	 * @param group: object of the group
	 * @param result: result binded from the view
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/groupCreate", method = RequestMethod.POST)
	public ModelAndView createGroup(
			@RequestParam("members") String listOfMembers,
			@ModelAttribute("command") Group group, BindingResult result,
			HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
 			
			String EMAIL_REGEX = "^[\\w-_\\.+]*(@metacube.com)";
			if((group.getGroupName() == "")||(group.getGroupName().length() < 3)){
				String error ="Please enter a valid Group Name,length should be greater then 3....!";
				return createGroup(request,error);
			}
			List<User> listOfUsers = new ArrayList<User>();
			String[] tokens = listOfMembers.split(".com");
			Set<String> uniqueMembers = new HashSet<String>();

			for (int i = 0; i < tokens.length; i++) {
				tokens[i] += ".com";
				uniqueMembers.add(tokens[i]);

			}

			for (String email : uniqueMembers) {
				User user = userServiceImpl.getUserByEmail(email);
				if(!email.matches(EMAIL_REGEX)){
					String error ="Please enter email with domain @metacube.com....!,  remove this"+email+" , ";
						
							return createGroup(request,error);
				}
				listOfUsers.add(user);
			}

			group.setUser(listOfUsers);
			Boolean status = groupService.addGroup(group);
	    if(!status){
	    	String error= "Group Already Exist or Could not added";
	    	return createGroup(request,error);
	    }
			return new ModelAndView("redirect:/UserHome.html?page=1");
		}
	}

	
	/**
	 * Method to delete a group
	 * @param group: group to be deleted
	 * @param result binded from the view
	 * @param request: request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/groupDelete", method = RequestMethod.POST)
	public ModelAndView DeleteGroup(@ModelAttribute("command") Group group,
			BindingResult result, HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			Boolean status = groupService.deleteGroup(group);
			return new ModelAndView("redirect:/UserHome.html?page=1");
		}
	}

	
	/**
	 * Method to list all the available users on CreateGroup page
	 * @param request: request parameter
	 * @param error: error message
	 * @return new ModelAndView
	 */
	@RequestMapping(value = "/creategroup", method = RequestMethod.GET)
	public ModelAndView createGroup(HttpServletRequest request,String error) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			System.out.println(error);
			request.setAttribute("error", error);
			Map<String, Object> model = new HashMap<String, Object>();
			model.put("command", new Group());
			List<String> list = new ArrayList<String>();
			for (User user : userServiceImpl.listUsers()) {
				list.add(user.getEmail());
			}
			Gson gson = new Gson();
			String json = gson.toJson(list);
			model.put("users", json);
			return new ModelAndView("CreateGroup", model);
		}
	}

	
	/**
	 * Method to list all the available groups on DeleteGroup page
	 * @param request: request parameter
	 * @return new ModelAndView
	 */
	@RequestMapping(value = "/deletegroup", method = RequestMethod.GET)
	public ModelAndView deleteGroup(HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			Map<String, Object> model = new HashMap<String, Object>();
			model.put("command", new Group());
			model.put("groups", groupService.listGroups());
			return new ModelAndView("DeleteGroup", model);
		}
	}

}
