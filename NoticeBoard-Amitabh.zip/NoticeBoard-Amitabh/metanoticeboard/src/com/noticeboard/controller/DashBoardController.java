package com.noticeboard.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.noticeboard.model.Notice;
import com.noticeboard.model.User;
import com.noticeboard.service.CommentService;
import com.noticeboard.service.GroupService;
import com.noticeboard.service.NoticeService;
import com.noticeboard.service.UserService;

/**
 * 
 * @author 
 * Description: This controller defines methods to perform tasks for 
 * 				Notice module
 */
@Controller("/DashBoardController")
public class DashBoardController {

	/**
	 * Object of "UserService"
	 */
	@Autowired
	private UserService userServiceImpl;
	
	/**
	 * Object of "NoticeService"
	 */
	@Autowired
	private NoticeService noticeService;
	
	/**
	 * Object of "GroupService"
	 */
	@Autowired
	private GroupService groupService;
	
	/**
	 * Object of "CommentService"
	 */
	@Autowired
	private CommentService commentService;

	/**
	 * Method to get all users having anniversary on the current date
	 * @param pageNo: page number for which data is to be find
	 * @param request: Request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/anniversary", method = RequestMethod.GET)
	public ModelAndView anniversory(@RequestParam("page") int pageNo,
			HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			Map<String, Object> model = new HashMap<String, Object>();
			List<User> listUsers = new ArrayList<User>();
			int page = 1;
			int recordsPerPage = 4;
			page = pageNo;
			listUsers.addAll(userServiceImpl.getUserByAnniversoryDate(
					((page - 1) * recordsPerPage), recordsPerPage));
			model.put("users", listUsers);

			int noOfRecords = userServiceImpl.getNoOfRecords();
			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
			model.put("noOfPages", noOfPages);
			model.put("currentPage", page);
			model.put("selectedTab", 3);
			
			return new ModelAndView("anniversary", model);
		}
	}

	/**
	 * Method to get all users having birthday on the current date
	 * @param pageNo: page number for which data is to be find
	 * @param request: Request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/birthDay", method = RequestMethod.GET)
	public ModelAndView birthDay(@RequestParam("page") int pageNo,
			HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			Map<String, Object> model = new HashMap<String, Object>();
			List<User> listUsers = new ArrayList<User>();
			int page = 1;
			int recordsPerPage = 4;
			page = pageNo;
			listUsers.addAll(userServiceImpl.getUserByBirthDayDate(
					((page - 1) * recordsPerPage), recordsPerPage));
			model.put("users", listUsers);

			int noOfRecords = userServiceImpl.getNoOfRecords();
			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
			model.put("noOfPages", noOfPages);
			model.put("currentPage", page);
			model.put("selectedTab", 4);
			return new ModelAndView("birthday", model);
		}
	}
	
	/**
	 * Method to get all notices having category "Announcement"
	 * @param pageNo: page number for which data is to be find
	 * @param request: Request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/announcements", method = RequestMethod.GET)
	public ModelAndView announcements(@RequestParam("page") int pageNo,
			HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			Map<String, Object> model = new HashMap<String, Object>();
			List<Notice> listNotice = new ArrayList<Notice>();
			User user = (User) request.getSession().getAttribute("user");
			int page = 1;
			int recordsPerPage = 3;
			page = pageNo;
			System.out.println(page+"####"+recordsPerPage);
			if (user.getRole().equals("SuperUser")) {
				listNotice.addAll(noticeService.getNoticeByCategoryForAdmin(
						((page - 1) * recordsPerPage), recordsPerPage, "Announcement"));
			}
			else {
				listNotice.addAll(noticeService.getNoticeByCategoryForUser(
						((page - 1) * recordsPerPage), recordsPerPage, "Announcement", user));
			}
			
			model.put("notices", listNotice);

			int noOfRecords = noticeService.getNoOfRecords();
			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
			model.put("noOfPages", noOfPages);
			model.put("currentPage", page);
			model.put("selectedTab", 2);
			model.put("url","announcements" );
			return new ModelAndView("UserHome", model);
		}
	}

	/**
	 * Method to get all notices having category "Event"
	 * @param pageNo: page number for which data is to be find
	 * @param request: Request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/events", method = RequestMethod.GET)
	public ModelAndView events(@RequestParam("page") int pageNo,
			HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			Map<String, Object> model = new HashMap<String, Object>();
			List<Notice> listNotice = new ArrayList<Notice>();
			User user = (User) request.getSession().getAttribute("user");
			int page = 1;
			int recordsPerPage = 3;
			page = pageNo;
			if (user.getRole().equals("SuperUser")) {
				listNotice.addAll(noticeService.getNoticeByCategoryForAdmin(
						((page - 1) * recordsPerPage), recordsPerPage, "Event"));
			}
			else {
				listNotice.addAll(noticeService.getNoticeByCategoryForUser(
						((page - 1) * recordsPerPage), recordsPerPage, "Event", user));
			}
			
			model.put("notices", listNotice);

			int noOfRecords = noticeService.getNoOfRecords();
			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
			model.put("noOfPages", noOfPages);
			model.put("currentPage", page);
			model.put("selectedTab", 5);
			model.put("url","events" );
			return new ModelAndView("UserHome", model);
		}
	}

	/**
	 * Method to get all notices having category "ClientPraise"
	 * @param pageNo: page number for which data is to be find
	 * @param request: Request parameter
	 * @return new modelAndView 
	 */
	@RequestMapping(value = "/clientPraise", method = RequestMethod.GET)
	public ModelAndView clientPraise(@RequestParam("page") int pageNo,
			HttpServletRequest request) {
		if (request.getSession().getAttribute("user") == null) {
			return new ModelAndView("index");
		} else {
			Map<String, Object> model = new HashMap<String, Object>();
			List<Notice> listNotice = new ArrayList<Notice>();
			User user = (User) request.getSession().getAttribute("user");
			int page = 1;
			int recordsPerPage = 3;
			page = pageNo;
			if (user.getRole().equals("SuperUser")) {
				listNotice.addAll(noticeService.getNoticeByCategoryForAdmin(
						((page - 1) * recordsPerPage), recordsPerPage,
						"ClientPraise"));
			}
			else {
				listNotice.addAll(noticeService.getNoticeByCategoryForUser(
						((page - 1) * recordsPerPage), recordsPerPage, "ClientPraise", user));
			}
			
			System.out.println(listNotice);
			model.put("notices", listNotice);

			int noOfRecords = noticeService.getNoOfRecords();
			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
			model.put("noOfPages", noOfPages);
			model.put("currentPage", page);
			model.put("selectedTab", 6);
			model.put("url","clientPraise" );
			return new ModelAndView("UserHome", model);
		}
	}

}
