package com.noticeboard.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.noticeboard.model.Notice;
import com.noticeboard.model.User;
import com.noticeboard.service.GoogleAuthService;
import com.noticeboard.service.GroupService;
import com.noticeboard.service.NoticeService;
import com.noticeboard.service.UserService;

/**
 * 
 * @author 
 * Description: This controller defines methods to perform tasks for 
 * 				Login authentication using Oauth
 */
@Controller
public class LoginController {

	@Autowired
	UserService userService;

	@Autowired
	GroupService groupService;
	@Autowired
	NoticeService noticeService;

	/**
	 * login with google oauth
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @throws IOException
	 * @throws JSONException
	 */
	@RequestMapping(value = "/loginWithOauth", method = RequestMethod.GET)
	public String oauthLogin(HttpServletRequest request,
			HttpServletResponse response) throws IOException, JSONException {
		String name;
		String email;
		User user;
		final GoogleAuthService helper = new GoogleAuthService();
		if (request.getParameter("code") != null
				&& request.getParameter("state") != null) {
			request.removeAttribute("state");

			JSONObject jsonObj = helper.getUserInfoJson(request
					.getParameter("code"));
			String hd = "";
			try {
				hd = (String) jsonObj.get("hd");

			} catch (Exception e) {
				return "redirect:hderror.html";
			}
			if (hd == null || hd.equals("") || !hd.equals("metacube.com")) {

				return "redirect:hderror.html";

			} else {
				name = (String) jsonObj.get("name");
				email = (String) jsonObj.get("email");

				user = userService.getUserByEmail(email);

				if (user == null || user.getUserName() == null
						|| user.getUserName().equals("")) {
					user = new User();
					user.setEmail(email);
					user.setUserName(name);
					user.setRole("User");
					userService.addUser(user);

				}
				request.getSession().invalidate();
				HttpSession httpSession = request.getSession(true);
				httpSession.removeAttribute("user");
				httpSession.setAttribute("user", user);

				return "redirect:UserHome.html?page=1";

			}

		} else {
			
			return "redirect:index.html";

		}

	}
	
	/**
	 * Method to redirect user to home page
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException
	 * @throws JSONException
	 */
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView firstPage(HttpServletRequest request,
			HttpServletResponse response) throws IOException, JSONException {
		System.out.println("Session"+request.getSession().getAttribute("user"));
		 
		return new ModelAndView("index");
	}
}
