$(document).ready(function() {
	$('#results').hide();
	 $('[data-toggle="tooltip"]').tooltip();  
});


function searching() {
	
	$('#results').show();
	$.getJSON("searchNotices.html", {
		CHARS : $('#searchText').val()
	}, function(data) {
		
		$('#results').text('');
		$('#scrollNotice').hide();
		$('#results').append("<h2>SEARCH RESULTS<span style='font-size: 15px;'>("+data.length+" Results found..)</span></h2>");
		for ( var index in data) {
			if(data[index].content.length > 150) {
				var showContent = data[index].content.substring(0,100);
				showContent += "  (<a href='noticecontent.html?id="+ data[index].noticeId+"'>view more</a>)";
			}
			else {
				var showContent = data[index].content;
			}
			var category = data[index].category;
			$('#results').append("<div class='panel panel-info'> <div class='panel-heading'>"
					+"<a>" + data[index].heading.toUpperCase()
					+ "</a>"+"("+category+")"
					+"</div>"
					+"<table id='tableContent' class='table noticeList' ><tbody>"
					+"<tr><td colspan='2'>" + showContent + "</td></tr>"
					+"</tbody></table></div>");
		}
		//$('#results').append("</table>");
		var i = 0;
		$('#results').find('a').each(function() {
			this.href = "noticecontent.html?id=" + data[i].noticeId;
			i++;
		});
	});

}

function getUserHome() {
	window.location = "UserHome.html?page=1";
}

function getAnniversaryHome() {
	window.location = "anniversary.html?page=1";
}

function getBirthDayHome() {
	window.location = "birthDay.html?page=1";
}

function getEventHome()
{
	window.location = "events.html?page=1";
	
}
function getClientPraise(){
	window.location = "clientPraise.html?page=1";
	
}


function getAnnouncementHome(){
	
	window.location = "announcements.html?page=1";
	
	
}

